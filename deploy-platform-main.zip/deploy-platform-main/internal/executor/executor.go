package executor

import (
	"context"
	"io"
)

type Target struct{ Host, User, CredentialProfile string }
type StepID string

// Executor accepts reviewed step IDs, never client-provided shell commands.
type Executor interface {
	RunStep(context.Context, Target, StepID, func(stream, line string)) error
	Upload(context.Context, Target, io.Reader, string) error
}
