package agent

import "context"

type Capability struct {
	Product     string   `json:"product"`
	DisplayName string   `json:"display_name"`
	Versions    []string `json:"versions"`
	Modes       []string `json:"modes"`
	NodeTypes   []string `json:"node_types"`
}

type Request struct {
	Product, Version, Mode, NodeType string
	Host, User, Package, InstallDir  string
	Options                          map[string]string
}

type Finding struct {
	Code, Message string
	Blocking      bool
}

type PrecheckResult struct{ Findings []Finding }

type Logger interface {
	Log(step, stream, message string)
}

// ProductAgent contains product knowledge only. It cannot accept arbitrary shell.
type ProductAgent interface {
	Capabilities() Capability
	Validate(Request) error
	Precheck(context.Context, Request, Logger) (PrecheckResult, error)
	Deploy(context.Context, Request, Logger) error
	Verify(context.Context, Request, Logger) error
}
