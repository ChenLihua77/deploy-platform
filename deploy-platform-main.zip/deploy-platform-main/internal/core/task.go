package core

import "time"

type Status string

const (
	Created              Status = "created"
	Prechecking          Status = "prechecking"
	PrecheckPassed       Status = "precheck_passed"
	PrecheckWarning      Status = "precheck_warning"
	PrecheckBlocked      Status = "precheck_blocked"
	AwaitingConfirmation Status = "awaiting_confirmation"
	Installing           Status = "installing"
	Verifying            Status = "verifying"
	Completed            Status = "completed"
	Failed               Status = "failed"
	Cancelled            Status = "cancelled"
)

type Task struct {
	ID, Product, Host string
	Status            Status
	CreatedAt         time.Time
}
