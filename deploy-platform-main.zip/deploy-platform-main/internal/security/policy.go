package security

import (
	"fmt"
	"net/netip"
)

type Policy struct{ Allowed map[netip.Addr]struct{} }

func (p Policy) AuthorizeHost(host string) error {
	a, e := netip.ParseAddr(host)
	if e != nil {
		return fmt.Errorf("invalid host")
	}
	if _, ok := p.Allowed[a]; !ok {
		return fmt.Errorf("host not allowed")
	}
	return nil
}
