package sshutil

import (
	"fmt"
	"golang.org/x/crypto/ssh"
	"golang.org/x/crypto/ssh/knownhosts"
	"net"
	"os"
	"path/filepath"
	"strconv"
)

func NormalizePort(port string) string {
	if port == "" {
		return "22"
	}
	return port
}

func HostKeyCallback(knownPath string) (ssh.HostKeyCallback, error) {
	if os.Getenv("DEPLOY_INSECURE_SKIP_HOST_KEY_CHECK") == "true" {
		return ssh.InsecureIgnoreHostKey(), nil
	}
	if knownPath == "" {
		knownPath = filepath.Join(os.Getenv("HOME"), ".ssh", "known_hosts")
	}
	return knownhosts.New(knownPath)
}

func Endpoint(host, port string) (string, error) {
	port = NormalizePort(port)
	p, err := strconv.Atoi(port)
	if err != nil || p < 1 || p > 65535 {
		return "", fmt.Errorf("SSH 代理端口必须是 1-65535")
	}
	return net.JoinHostPort(host, port), nil
}
