package sshutil

import "testing"

func TestEndpoint(t *testing.T) {
	tests := []struct {
		host, port, want string
		ok               bool
	}{
		{"10.0.0.1", "", "10.0.0.1:22", true},
		{"10.0.0.1", "2222", "10.0.0.1:2222", true},
		{"2001:db8::1", "2200", "[2001:db8::1]:2200", true},
		{"10.0.0.1", "0", "", false},
		{"10.0.0.1", "65536", "", false},
		{"10.0.0.1", "abc", "", false},
	}
	for _, tt := range tests {
		got, err := Endpoint(tt.host, tt.port)
		if (err == nil) != tt.ok || got != tt.want {
			t.Errorf("Endpoint(%q,%q)=%q,%v; want %q ok=%v", tt.host, tt.port, got, err, tt.want, tt.ok)
		}
	}
}
