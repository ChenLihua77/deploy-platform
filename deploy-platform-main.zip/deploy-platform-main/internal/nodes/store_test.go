package nodes

import (
	"path/filepath"
	"testing"
)

func TestDeleteAuditSelectedAndAll(t *testing.T) {
	store, err := NewStore(filepath.Join(t.TempDir(), "nodes.json"), false)
	if err != nil {
		t.Fatal(err)
	}
	if err := store.Add(Node{IP: "10.0.0.1", Name: "one"}); err != nil {
		t.Fatal(err)
	}
	if err := store.Add(Node{IP: "10.0.0.2", Name: "two"}); err != nil {
		t.Fatal(err)
	}
	entries := store.Audit()
	deleted, err := store.DeleteAudit(entries[:1], false)
	if err != nil || deleted != 1 || len(store.Audit()) != 1 {
		t.Fatalf("selected delete: deleted=%d remaining=%d err=%v", deleted, len(store.Audit()), err)
	}
	deleted, err = store.DeleteAudit(nil, true)
	if err != nil || deleted != 1 || len(store.Audit()) != 0 {
		t.Fatalf("clear all: deleted=%d remaining=%d err=%v", deleted, len(store.Audit()), err)
	}
	if store.Audit() == nil {
		t.Fatal("empty audit must be encoded as [] instead of null")
	}
	reloaded, err := NewStore(store.path, false)
	if err != nil || len(reloaded.Audit()) != 0 {
		t.Fatalf("persisted audit: remaining=%d err=%v", len(reloaded.Audit()), err)
	}
}
