package nodes

import (
	"encoding/json"
	"fmt"
	"net/netip"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type Node struct {
	IP        string    `json:"ip"`
	Name      string    `json:"name"`
	Note      string    `json:"note,omitempty"`
	Public    bool      `json:"public"`
	CreatedAt time.Time `json:"created_at"`
}

type Audit struct {
	Time   string `json:"time"`
	Action string `json:"action"`
	Target string `json:"target"`
	Detail string `json:"detail"`
}

type Store struct {
	mu          sync.RWMutex
	path        string
	auditPath   string
	allowPublic bool
	nodes       map[string]Node
	audit       []Audit
}

func NewStore(path string, allowPublic bool) (*Store, error) {
	s := &Store{path: path, auditPath: filepath.Join(filepath.Dir(path), "audit.json"), allowPublic: allowPublic, nodes: map[string]Node{}}
	b, err := os.ReadFile(path)
	if err == nil {
		var list []Node
		if err := json.Unmarshal(b, &list); err != nil {
			return nil, fmt.Errorf("读取节点配置失败: %w", err)
		}
		for _, n := range list {
			s.nodes[n.IP] = n
		}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	if b, err := os.ReadFile(s.auditPath); err == nil {
		if err := json.Unmarshal(b, &s.audit); err != nil {
			return nil, fmt.Errorf("读取审计日志失败: %w", err)
		}
	} else if !os.IsNotExist(err) {
		return nil, err
	}
	return s, nil
}

func (s *Store) List() []Node {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]Node, 0, len(s.nodes))
	for _, n := range s.nodes {
		out = append(out, n)
	}
	return out
}

func (s *Store) Contains(ip string) bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	_, ok := s.nodes[ip]
	return ok
}

func (s *Store) Add(n Node) error {
	a, err := netip.ParseAddr(strings.TrimSpace(n.IP))
	if err != nil {
		return fmt.Errorf("请输入合法 IP 地址")
	}
	if !a.IsPrivate() && !s.allowPublic {
		return fmt.Errorf("公网节点未启用临时测试例外")
	}
	n.IP = a.String()
	n.Name = strings.TrimSpace(n.Name)
	n.Note = strings.TrimSpace(n.Note)
	if n.Name == "" {
		n.Name = n.IP
	}
	n.Public = !a.IsPrivate()
	n.CreatedAt = time.Now()
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.nodes[n.IP]; ok {
		return fmt.Errorf("节点已存在")
	}
	s.nodes[n.IP] = n
	s.audit = append(s.audit, Audit{time.Now().Format(time.RFC3339), "node.add", n.IP, n.Name})
	return s.saveLocked()
}

func (s *Store) Delete(ip string) error {
	a, err := netip.ParseAddr(ip)
	if err != nil {
		return fmt.Errorf("非法 IP")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if _, ok := s.nodes[a.String()]; !ok {
		return fmt.Errorf("节点不存在")
	}
	delete(s.nodes, a.String())
	s.audit = append(s.audit, Audit{time.Now().Format(time.RFC3339), "node.delete", a.String(), "管理员删除"})
	return s.saveLocked()
}

func (s *Store) Audit() []Audit {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return append([]Audit{}, s.audit...)
}

func (s *Store) DeleteAudit(selected []Audit, all bool) (int, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if all {
		deleted := len(s.audit)
		s.audit = []Audit{}
		return deleted, s.saveAuditLocked()
	}
	wanted := make(map[string]struct{}, len(selected))
	for _, item := range selected {
		wanted[item.Time+"\x00"+item.Action+"\x00"+item.Target] = struct{}{}
	}
	kept := make([]Audit, 0, len(s.audit))
	deleted := 0
	for _, item := range s.audit {
		key := item.Time + "\x00" + item.Action + "\x00" + item.Target
		if _, ok := wanted[key]; ok {
			deleted++
			continue
		}
		kept = append(kept, item)
	}
	s.audit = kept
	return deleted, s.saveAuditLocked()
}

func (s *Store) saveAuditLocked() error {
	if err := os.MkdirAll(filepath.Dir(s.auditPath), 0700); err != nil {
		return err
	}
	ab, err := json.MarshalIndent(s.audit, "", "  ")
	if err != nil {
		return err
	}
	atmp := s.auditPath + ".tmp"
	if err := os.WriteFile(atmp, ab, 0600); err != nil {
		return err
	}
	return os.Rename(atmp, s.auditPath)
}

func (s *Store) saveLocked() error {
	list := make([]Node, 0, len(s.nodes))
	for _, n := range s.nodes {
		list = append(list, n)
	}
	b, err := json.MarshalIndent(list, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(s.path), 0700); err != nil {
		return err
	}
	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0600); err != nil {
		return err
	}
	if err := os.Rename(tmp, s.path); err != nil {
		return err
	}
	return s.saveAuditLocked()
}
