package registry

import (
	"fmt"
	"sort"
	"sync"

	"deploy-platform/internal/agent"
)

type Registry struct {
	mu     sync.RWMutex
	agents map[string]agent.ProductAgent
}

func New() *Registry { return &Registry{agents: map[string]agent.ProductAgent{}} }
func (r *Registry) Register(a agent.ProductAgent) error {
	c := a.Capabilities()
	if c.Product == "" {
		return fmt.Errorf("empty product id")
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, ok := r.agents[c.Product]; ok {
		return fmt.Errorf("product %s already registered", c.Product)
	}
	r.agents[c.Product] = a
	return nil
}
func (r *Registry) Get(id string) (agent.ProductAgent, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	a, ok := r.agents[id]
	return a, ok
}
func (r *Registry) Capabilities() []agent.Capability {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]agent.Capability, 0, len(r.agents))
	for _, a := range r.agents {
		out = append(out, a.Capabilities())
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Product < out[j].Product })
	return out
}
