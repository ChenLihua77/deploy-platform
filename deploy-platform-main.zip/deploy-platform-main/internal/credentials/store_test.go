package credentials

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func TestEncryptedCredentialRoundTrip(t *testing.T) {
	t.Setenv("DEPLOY_CREDENTIAL_KEY", "test-key-that-is-not-used-in-production")
	credentialFile := filepath.Join(t.TempDir(), "credentials.enc")
	t.Setenv("DEPLOY_CREDENTIAL_FILE", credentialFile)
	if _, err := Resolve("10.0.0.1", "2222", "root", "secret"); err != nil {
		t.Fatal(err)
	}
	got, err := Resolve("10.0.0.1", "2222", "root", "")
	if err != nil || got != "secret" {
		t.Fatalf("got=%q err=%v", got, err)
	}
	b, err := os.ReadFile(credentialFile)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(b, []byte("secret")) {
		t.Fatal("credential file contains plaintext password")
	}
}
