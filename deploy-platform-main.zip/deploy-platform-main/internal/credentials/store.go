package credentials

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
)

var mu sync.Mutex

func Enabled() bool { return os.Getenv("DEPLOY_CREDENTIAL_KEY") != "" }

func Resolve(host, port, user, supplied string) (string, error) {
	if supplied != "" {
		if Enabled() {
			return supplied, Save(host, port, user, supplied)
		}
		return supplied, nil
	}
	if !Enabled() {
		return "", fmt.Errorf("SSH 密码为空且未设置 DEPLOY_CREDENTIAL_KEY")
	}
	password, err := Load(host, port, user)
	if err != nil {
		return "", err
	}
	if password == "" {
		return "", fmt.Errorf("未找到该目标、端口和用户对应的已保存 SSH 密码")
	}
	return password, nil
}

func Save(host, port, user, password string) error {
	mu.Lock()
	defer mu.Unlock()
	items, err := loadLocked()
	if err != nil {
		return err
	}
	items[key(host, port, user)] = password
	plain, err := json.Marshal(items)
	if err != nil {
		return err
	}
	block, err := aes.NewCipher(deriveKey())
	if err != nil {
		return err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err = rand.Read(nonce); err != nil {
		return err
	}
	sealed := gcm.Seal(nil, nonce, plain, nil)
	path := credentialPath()
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, append(nonce, sealed...), 0600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

func Load(host, port, user string) (string, error) {
	mu.Lock()
	defer mu.Unlock()
	items, err := loadLocked()
	if err != nil {
		return "", err
	}
	return items[key(host, port, user)], nil
}

func loadLocked() (map[string]string, error) {
	items := map[string]string{}
	b, err := os.ReadFile(credentialPath())
	if os.IsNotExist(err) {
		return items, nil
	}
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(deriveKey())
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	if len(b) < gcm.NonceSize() {
		return nil, fmt.Errorf("SSH 凭据文件格式无效")
	}
	plain, err := gcm.Open(nil, b[:gcm.NonceSize()], b[gcm.NonceSize():], nil)
	if err != nil {
		return nil, fmt.Errorf("SSH 凭据解密失败，请确认 DEPLOY_CREDENTIAL_KEY 未变化")
	}
	if err := json.Unmarshal(plain, &items); err != nil {
		return nil, err
	}
	return items, nil
}

func deriveKey() []byte {
	sum := sha256.Sum256([]byte(os.Getenv("DEPLOY_CREDENTIAL_KEY")))
	return sum[:]
}
func key(host, port, user string) string { return host + "\x00" + port + "\x00" + user }
func credentialPath() string {
	if p := os.Getenv("DEPLOY_CREDENTIAL_FILE"); p != "" {
		return p
	}
	return filepath.Join("data", "ssh-credentials.enc")
}
