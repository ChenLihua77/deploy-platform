package muyun

import (
	"bufio"
	"crypto/md5"
	"deploy-platform/internal/credentials"
	"deploy-platform/internal/sshutil"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

type DeployRequest struct {
	Version         string `json:"version"`
	Host            string `json:"host"`
	User            string `json:"user"`
	SSHPassword     string `json:"ssh_password"`
	SSHPort         string `json:"ssh_port"`
	Package         string `json:"package"`
	PackagePassword string `json:"package_password"`
	InstallDir      string `json:"install_dir"`
	ExpectedMD5     string `json:"expected_md5"`
	PrecheckID      string `json:"precheck_id"`
	RiskReason      string `json:"risk_reason"`
	Confirmed       bool   `json:"confirmed"`
	RiskOverride    bool   `json:"risk_override"`
}
type Task struct {
	ID, Status, Error string
	Logs, Warnings    []string
	Request           DeployRequest
}
type Runtime struct {
	mu      sync.RWMutex
	tasks   map[string]*Task
	allowed func(string) bool
}

func NewRuntime(allowed func(string) bool) *Runtime {
	return &Runtime{tasks: map[string]*Task{}, allowed: allowed}
}
func (rt *Runtime) Register(m *http.ServeMux) {
	m.HandleFunc("POST /api/v1/muyun/precheck", rt.precheckAPI)
	m.HandleFunc("POST /api/v1/muyun/deploy", rt.deployAPI)
	m.HandleFunc("GET /api/v1/muyun/tasks/{id}", rt.taskAPI)
}
func decode(r *http.Request) (DeployRequest, error) {
	var x DeployRequest
	e := json.NewDecoder(r.Body).Decode(&x)
	if x.InstallDir == "" {
		x.InstallDir = "/data/cloudwalker"
	}
	x.SSHPort = sshutil.NormalizePort(x.SSHPort)
	if e == nil {
		x.SSHPassword, e = credentials.Resolve(x.Host, x.SSHPort, x.User, x.SSHPassword)
	}
	return x, e
}
func (rt *Runtime) validate(x DeployRequest) error {
	if !rt.allowed(x.Host) {
		return fmt.Errorf("目标节点不在平台白名单中")
	}
	if x.Version == "" || x.User == "" || x.SSHPassword == "" || x.Package == "" || x.PackagePassword == "" {
		return fmt.Errorf("版本、SSH 信息、安装包和安装包密码不能为空")
	}
	if _, err := sshutil.Endpoint(x.Host, x.SSHPort); err != nil {
		return err
	}
	if !filepath.IsAbs(x.Package) || !filepath.IsAbs(x.InstallDir) {
		return fmt.Errorf("安装包和安装目录必须使用绝对路径")
	}
	if x.InstallDir == "/" || strings.HasPrefix(x.InstallDir, "/root") || strings.HasPrefix(x.InstallDir, "/home") {
		return fmt.Errorf("安装目录不能是根目录或用户家目录")
	}
	if x.ExpectedMD5 != "" && !regexp.MustCompile(`(?i)^[0-9a-f]{32}$`).MatchString(x.ExpectedMD5) {
		return fmt.Errorf("期望 MD5 格式错误")
	}
	return nil
}
func (rt *Runtime) precheckAPI(w http.ResponseWriter, r *http.Request) {
	x, e := decode(r)
	if e != nil {
		http.Error(w, "请求格式错误", 400)
		return
	}
	if e = rt.validate(x); e != nil {
		http.Error(w, e.Error(), 400)
		return
	}
	t := rt.newTask(x, "prechecking")
	go rt.precheck(t)
	output(w, t)
}
func (rt *Runtime) deployAPI(w http.ResponseWriter, r *http.Request) {
	x, e := decode(r)
	if e != nil {
		http.Error(w, "请求格式错误", 400)
		return
	}
	if e = rt.validate(x); e != nil {
		http.Error(w, e.Error(), 400)
		return
	}
	if !x.Confirmed {
		http.Error(w, "正式安装需要二次确认", 412)
		return
	}
	rt.mu.RLock()
	p := rt.tasks[x.PrecheckID]
	rt.mu.RUnlock()
	if p == nil || p.Status != "precheck_passed" {
		http.Error(w, "必须先完成相同参数的预检", 412)
		return
	}
	if !same(p.Request, x) {
		http.Error(w, "参数已变化，请重新预检", 412)
		return
	}
	if len(p.Warnings) > 0 && (!x.RiskOverride || strings.TrimSpace(x.RiskReason) == "") {
		http.Error(w, "存在风险项，必须确认并填写原因", 412)
		return
	}
	t := rt.newTask(x, "installing")
	go rt.deploy(t)
	output(w, t)
}
func (rt *Runtime) taskAPI(w http.ResponseWriter, r *http.Request) {
	rt.mu.RLock()
	t := rt.tasks[r.PathValue("id")]
	rt.mu.RUnlock()
	if t == nil {
		http.NotFound(w, r)
		return
	}
	output(w, t)
}
func output(w http.ResponseWriter, t *Task) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"id": t.ID, "status": t.Status, "error": t.Error, "logs": t.Logs, "warnings": t.Warnings})
}
func (rt *Runtime) newTask(x DeployRequest, status string) *Task {
	t := &Task{ID: fmt.Sprint(time.Now().UnixNano()), Status: status, Request: x}
	rt.mu.Lock()
	rt.tasks[t.ID] = t
	rt.mu.Unlock()
	return t
}
func same(a, b DeployRequest) bool {
	return a.Version == b.Version && a.Host == b.Host && a.SSHPort == b.SSHPort && a.User == b.User && a.Package == b.Package && a.InstallDir == b.InstallDir && strings.EqualFold(a.ExpectedMD5, b.ExpectedMD5)
}

func (rt *Runtime) precheck(t *Task) {
	defer wipe(t)
	rt.log(t, "开始牧云单机管理端预检")
	sum, e := fileMD5(t.Request.Package)
	if e != nil {
		rt.fail(t, "安装包读取失败: "+e.Error())
		return
	}
	rt.log(t, "安装包 MD5: "+sum)
	if t.Request.ExpectedMD5 != "" && !strings.EqualFold(sum, t.Request.ExpectedMD5) {
		rt.fail(t, "安装包 MD5 与期望值不一致")
		return
	}
	cmd := `set -e
. /etc/os-release
echo "OS=$ID ${VERSION_ID:-unknown}"
echo "KERNEL=$(uname -r)"
test "$(uname -r | cut -d- -f1)" != ""
test "$(getconf PAGESIZE)" -ne 65536 || { echo "ARM 64K page size 不受支持" >&2; exit 21; }
[ "$(nproc)" -ge 4 ] || echo "RISK:CPU 少于 4 核"
[ "$(awk '/MemTotal/{print $2}' /proc/meminfo)" -ge 16777216 ] || echo "RISK:内存少于 16GiB"
[ "$(df -Pk ` + quote(t.Request.InstallDir) + ` 2>/dev/null | awk 'NR==2{print $4}' || df -Pk / | awk 'NR==2{print $4}')" -ge 209715200 ] || echo "RISK:安装盘可用空间少于 200GiB"
[ "$(df -Pk /var | awk 'NR==2{print $4}')" -ge 52428800 ] || { echo "/var 可用空间少于 50GiB" >&2; exit 22; }
[ "$(umask)" = "0022" ] || echo "RISK:umask 不是 0022"
[ "$(swapon --noheadings 2>/dev/null | wc -l | tr -d ' ')" = "0" ] || echo "RISK:Swap 已启用"
command -v getenforce >/dev/null && [ "$(getenforce)" = "Disabled" ] || echo "RISK:SELinux 可能未关闭"
command -v docker >/dev/null && docker --version || echo "INFO:未安装 Docker，安装器可能自动安装"
timedatectl status 2>/dev/null || true
ss -lnt 2>/dev/null | grep -E ':(443|50051|8000|3399)[[:space:]]' && { echo "必要端口已占用" >&2; exit 23; } || true
echo PRECHECK_OK`
	if e = rt.remote(t, cmd, ""); e != nil {
		rt.fail(t, "预检硬阻断: "+e.Error())
		return
	}
	rt.mu.Lock()
	for _, l := range t.Logs {
		if i := strings.Index(l, "RISK:"); i >= 0 {
			t.Warnings = append(t.Warnings, l[i+5:])
		}
	}
	t.Status = "precheck_passed"
	rt.mu.Unlock()
	rt.log(t, "预检完成")
}
func (rt *Runtime) deploy(t *Task) {
	defer wipe(t)
	remotePkg := "/tmp/cloudwalker-installer-" + t.ID + ".bin"
	rt.log(t, "阶段 1/4：创建目录并上传安装包")
	if e := rt.remote(t, "mkdir -p "+quote(t.Request.InstallDir), ""); e != nil {
		rt.fail(t, e.Error())
		return
	}
	if e := rt.upload(t, remotePkg); e != nil {
		rt.fail(t, e.Error())
		return
	}
	rt.log(t, "阶段 2/4：执行牧云安装器")
	if e := rt.remote(t, "chmod 700 "+quote(remotePkg)+" && "+quote(remotePkg)+" -C "+quote(t.Request.InstallDir), t.Request.PackagePassword+"\n"); e != nil {
		rt.fail(t, "安装器失败: "+e.Error())
		return
	}
	rt.log(t, "阶段 3/4：检查 minion 和容器")
	check := "systemctl is-active minion && (cd " + quote(t.Request.InstallDir) + " && ./minion compose ps || docker ps)"
	if e := rt.remote(t, check, ""); e != nil {
		rt.fail(t, "服务检查失败: "+e.Error())
		return
	}
	rt.log(t, "阶段 4/4：检查 HTTPS 管理端口")
	if e := rt.remote(t, "ss -lnt | grep -E ':443[[:space:]]'", ""); e != nil {
		rt.fail(t, "HTTPS 443 未监听: "+e.Error())
		return
	}
	rt.mu.Lock()
	t.Status = "completed"
	rt.mu.Unlock()
	rt.log(t, "牧云单机管理端部署完成")
}

func fileMD5(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := md5.New()
	_, e = io.Copy(h, f)
	return hex.EncodeToString(h.Sum(nil)), e
}
func (rt *Runtime) client(t *Task) (*ssh.Client, error) {
	kp := os.Getenv("DEPLOY_KNOWN_HOSTS")
	if kp == "" {
		kp = filepath.Join(os.Getenv("HOME"), ".ssh", "known_hosts")
	}
	cb, e := sshutil.HostKeyCallback(kp)
	if e != nil {
		return nil, e
	}
	endpoint, e := sshutil.Endpoint(t.Request.Host, t.Request.SSHPort)
	if e != nil {
		return nil, e
	}
	return ssh.Dial("tcp", endpoint, &ssh.ClientConfig{User: t.Request.User, Auth: []ssh.AuthMethod{ssh.Password(t.Request.SSHPassword)}, HostKeyCallback: cb, Timeout: 15 * time.Second})
}
func (rt *Runtime) remote(t *Task, cmd, input string) error {
	rt.log(t, "执行: "+cmd)
	c, e := rt.client(t)
	if e != nil {
		return e
	}
	defer c.Close()
	s, e := c.NewSession()
	if e != nil {
		return e
	}
	defer s.Close()
	out, _ := s.StdoutPipe()
	er, _ := s.StderrPipe()
	in, _ := s.StdinPipe()
	if e = s.Start("bash -lc " + quote(cmd)); e != nil {
		return e
	}
	if input != "" {
		go func() { io.WriteString(in, input); in.Close() }()
	}
	var wg sync.WaitGroup
	stream := func(r io.Reader, p string) {
		defer wg.Done()
		sc := bufio.NewScanner(r)
		sc.Buffer(make([]byte, 65536), 1024*1024)
		for sc.Scan() {
			rt.log(t, p+sc.Text())
		}
	}
	wg.Add(2)
	go stream(out, "[stdout] ")
	go stream(er, "[stderr] ")
	e = s.Wait()
	wg.Wait()
	return e
}
func (rt *Runtime) upload(t *Task, dst string) error {
	c, e := rt.client(t)
	if e != nil {
		return e
	}
	defer c.Close()
	s, e := c.NewSession()
	if e != nil {
		return e
	}
	defer s.Close()
	in, e := s.StdinPipe()
	if e != nil {
		return e
	}
	if e = s.Start("cat > " + quote(dst)); e != nil {
		return e
	}
	f, e := os.Open(t.Request.Package)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = io.Copy(in, f)
	in.Close()
	if e != nil {
		return e
	}
	return s.Wait()
}
func (rt *Runtime) log(t *Task, s string) {
	rt.mu.Lock()
	t.Logs = append(t.Logs, time.Now().Format("15:04:05 ")+s)
	rt.mu.Unlock()
}
func (rt *Runtime) fail(t *Task, s string) {
	rt.mu.Lock()
	t.Status = "failed"
	t.Error = s
	rt.mu.Unlock()
	rt.log(t, "失败: "+s)
}
func wipe(t *Task)          { t.Request.SSHPassword = ""; t.Request.PackagePassword = "" }
func quote(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
