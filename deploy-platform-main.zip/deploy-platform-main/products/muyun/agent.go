package muyun

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"

	"deploy-platform/internal/agent"
)

type Agent struct{}

func New() *Agent { return &Agent{} }

func (*Agent) Capabilities() agent.Capability {
	return agent.Capability{
		Product:     "muyun",
		DisplayName: "牧云（CloudWalker）主机安全管理平台",
		Versions:    []string{"具体版本需按安装包适配"},
		Modes:       []string{"standalone", "k8s-cluster"},
		NodeTypes:   []string{"management", "linux-agent", "windows-agent"},
	}
}

func (*Agent) Validate(r agent.Request) error {
	if r.Product != "muyun" {
		return fmt.Errorf("产品类型必须为 muyun")
	}
	if strings.TrimSpace(r.Version) == "" {
		return fmt.Errorf("必须填写安装包对应的具体版本")
	}
	if r.Mode != "standalone" && r.Mode != "k8s-cluster" {
		return fmt.Errorf("仅支持单机或 K8s 集群模式")
	}
	if r.NodeType != "management" && r.NodeType != "linux-agent" && r.NodeType != "windows-agent" {
		return fmt.Errorf("节点类型无效")
	}
	if r.Host == "" || r.User == "" {
		return fmt.Errorf("目标节点和 SSH 用户不能为空")
	}
	if r.NodeType == "management" {
		if !filepath.IsAbs(r.Package) {
			return fmt.Errorf("管理端安装包必须使用本机绝对路径")
		}
		if r.InstallDir == "" || !filepath.IsAbs(r.InstallDir) {
			return fmt.Errorf("安装目录必须使用绝对路径")
		}
	}
	if r.Mode == "k8s-cluster" && r.NodeType != "management" {
		return fmt.Errorf("集群模式当前只定义管理服务部署")
	}
	return nil
}

func (*Agent) Precheck(context.Context, agent.Request, agent.Logger) (agent.PrecheckResult, error) {
	return agent.PrecheckResult{}, fmt.Errorf("牧云执行器尚未启用，请先完成单机安装模板验证")
}
func (*Agent) Deploy(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("牧云执行器尚未启用，请先完成单机安装模板验证")
}
func (*Agent) Verify(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("牧云执行器尚未启用，请先完成单机安装模板验证")
}
