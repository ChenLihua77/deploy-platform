package dongjian

import (
	"context"
	"fmt"
	"strings"

	"deploy-platform/internal/agent"
)

type Agent struct{}

func New() *Agent { return &Agent{} }

func (*Agent) Capabilities() agent.Capability {
	return agent.Capability{
		Product: "dongjian", DisplayName: "洞鉴（X-Ray）安全评估系统",
		Versions:  []string{"25.04.0~25.12.0"},
		Modes:     []string{"standalone", "distributed"},
		NodeTypes: []string{"management", "engine"},
	}
}

func (*Agent) Validate(r agent.Request) error {
	if r.Product != "dongjian" {
		return fmt.Errorf("产品类型必须为 dongjian")
	}
	if r.Version == "" {
		return fmt.Errorf("必须选择经过适配的具体版本")
	}
	if r.Mode != "standalone" && r.Mode != "distributed" {
		return fmt.Errorf("仅支持单机或分布式部署")
	}
	if r.NodeType != "management" && r.NodeType != "engine" {
		return fmt.Errorf("节点类型必须为 management 或 engine")
	}
	if r.Host == "" || r.User == "" || r.Package == "" {
		return fmt.Errorf("目标节点、SSH 用户和安装包不能为空")
	}
	if r.InstallDir == "" {
		r.InstallDir = "/data/x-ray"
	}
	if !strings.HasPrefix(r.InstallDir, "/") {
		return fmt.Errorf("安装目录必须是绝对路径")
	}
	if r.Mode == "distributed" && r.NodeType == "engine" {
		if r.Options["mgmt_ip"] == "" || r.Options["mgmt_id"] == "" || r.Options["engine_ip"] == "" {
			return fmt.Errorf("分布式引擎节点必须配置 mgmt_ip、mgmt_id 和 engine_ip")
		}
	}
	return nil
}

func (*Agent) Precheck(context.Context, agent.Request, agent.Logger) (agent.PrecheckResult, error) {
	return agent.PrecheckResult{}, fmt.Errorf("洞鉴执行器尚未启用，请先完成命令模板评审")
}
func (*Agent) Deploy(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("洞鉴执行器尚未启用，请先完成命令模板评审")
}
func (*Agent) Verify(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("洞鉴执行器尚未启用，请先完成命令模板评审")
}
