package dongjian

import (
	"bufio"
	"crypto/md5"
	"deploy-platform/internal/credentials"
	"deploy-platform/internal/sshutil"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

type DeployRequest struct {
	Version         string `json:"version"`
	Mode            string `json:"mode"`
	NodeType        string `json:"node_type"`
	Host            string `json:"host"`
	User            string `json:"user"`
	SSHPassword     string `json:"ssh_password"`
	SSHPort         string `json:"ssh_port"`
	Package         string `json:"package"`
	PackagePassword string `json:"package_password"`
	InstallDir      string `json:"install_dir"`
	EngineIP        string `json:"engine_ip"`
	MgmtIP          string `json:"mgmt_ip"`
	MgmtID          string `json:"mgmt_id"`
	PrecheckID      string `json:"precheck_id"`
	RiskReason      string `json:"risk_reason"`
	Confirmed       bool   `json:"confirmed"`
	RiskOverride    bool   `json:"risk_override"`
}
type Task struct {
	ID, Status, Error string
	Logs, Warnings    []string
	Request           DeployRequest
}
type Runtime struct {
	mu      sync.RWMutex
	tasks   map[string]*Task
	allowed func(string) bool
}

func NewRuntime(allowed func(string) bool) *Runtime {
	return &Runtime{tasks: map[string]*Task{}, allowed: allowed}
}
func (rt *Runtime) Register(m *http.ServeMux) {
	m.HandleFunc("POST /api/v1/dongjian/precheck", rt.createPrecheck)
	m.HandleFunc("POST /api/v1/dongjian/deploy", rt.createDeploy)
	m.HandleFunc("GET /api/v1/dongjian/tasks/{id}", rt.getTask)
}
func decode(r *http.Request) (DeployRequest, error) {
	var x DeployRequest
	e := json.NewDecoder(r.Body).Decode(&x)
	if x.InstallDir == "" {
		x.InstallDir = "/data/x-ray"
	}
	x.SSHPort = sshutil.NormalizePort(x.SSHPort)
	if e == nil {
		x.SSHPassword, e = credentials.Resolve(x.Host, x.SSHPort, x.User, x.SSHPassword)
	}
	return x, e
}
func (rt *Runtime) createPrecheck(w http.ResponseWriter, r *http.Request) {
	x, e := decode(r)
	if e != nil {
		http.Error(w, "请求格式错误", 400)
		return
	}
	if e = rt.validate(x); e != nil {
		http.Error(w, e.Error(), 400)
		return
	}
	t := rt.newTask(x, "prechecking")
	go rt.precheck(t)
	write(w, t)
}
func (rt *Runtime) createDeploy(w http.ResponseWriter, r *http.Request) {
	x, e := decode(r)
	if e != nil {
		http.Error(w, "请求格式错误", 400)
		return
	}
	if e = rt.validate(x); e != nil {
		http.Error(w, e.Error(), 400)
		return
	}
	if !x.Confirmed {
		http.Error(w, "正式安装需要二次确认", 412)
		return
	}
	rt.mu.RLock()
	p := rt.tasks[x.PrecheckID]
	rt.mu.RUnlock()
	if p == nil || p.Status != "precheck_passed" {
		http.Error(w, "必须先完成相同参数的预检", 412)
		return
	}
	if !same(p.Request, x) {
		http.Error(w, "部署参数已变化，请重新预检", 412)
		return
	}
	if len(p.Warnings) > 0 && (!x.RiskOverride || strings.TrimSpace(x.RiskReason) == "") {
		http.Error(w, "存在风险项，必须确认并填写原因", 412)
		return
	}
	t := rt.newTask(x, "installing")
	go rt.deploy(t)
	write(w, t)
}
func (rt *Runtime) getTask(w http.ResponseWriter, r *http.Request) {
	rt.mu.RLock()
	t := rt.tasks[r.PathValue("id")]
	rt.mu.RUnlock()
	if t == nil {
		http.NotFound(w, r)
		return
	}
	write(w, t)
}
func write(w http.ResponseWriter, t *Task) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"id": t.ID, "status": t.Status, "error": t.Error, "logs": t.Logs, "warnings": t.Warnings})
}
func (rt *Runtime) newTask(x DeployRequest, s string) *Task {
	t := &Task{ID: fmt.Sprint(time.Now().UnixNano()), Status: s, Request: x}
	rt.mu.Lock()
	rt.tasks[t.ID] = t
	rt.mu.Unlock()
	return t
}
func (rt *Runtime) validate(x DeployRequest) error {
	if !rt.allowed(x.Host) {
		return fmt.Errorf("目标节点不在平台白名单中")
	}
	if x.User == "" || x.SSHPassword == "" || x.Package == "" || x.PackagePassword == "" {
		return fmt.Errorf("SSH 用户、临时密码、安装包和安装包密码不能为空")
	}
	if _, err := sshutil.Endpoint(x.Host, x.SSHPort); err != nil {
		return err
	}
	if x.Mode != "standalone" && x.Mode != "distributed" {
		return fmt.Errorf("部署模式无效")
	}
	if x.NodeType != "management" && x.NodeType != "engine" {
		return fmt.Errorf("节点类型无效")
	}
	if !filepath.IsAbs(x.Package) || !filepath.IsAbs(x.InstallDir) {
		return fmt.Errorf("安装包和安装目录必须使用绝对路径")
	}
	if x.Mode == "distributed" && x.NodeType == "engine" && (x.EngineIP == "" || x.MgmtIP == "" || x.MgmtID == "") {
		return fmt.Errorf("分布式引擎必须填写 engine_ip、mgmt_ip、mgmt_id")
	}
	return nil
}
func same(a, b DeployRequest) bool {
	return a.Version == b.Version && a.Mode == b.Mode && a.NodeType == b.NodeType && a.Host == b.Host && a.SSHPort == b.SSHPort && a.User == b.User && a.Package == b.Package && a.InstallDir == b.InstallDir && a.EngineIP == b.EngineIP && a.MgmtIP == b.MgmtIP && a.MgmtID == b.MgmtID
}

func (rt *Runtime) precheck(t *Task) {
	defer wipe(t)
	rt.log(t, "开始洞鉴环境预检")
	if _, e := os.Stat(t.Request.Package); e != nil {
		rt.fail(t, "读取安装包失败: "+e.Error())
		return
	}
	if e := hash(t, rt); e != nil {
		rt.fail(t, e.Error())
		return
	}
	cmd := `set -e; . /etc/os-release; echo "OS=$ID ${VERSION_ID:-unknown}"; test "$(uname -r | cut -d- -f1)" != ""; test "$(nproc)" -ge 2; grep -qi ssse3 /proc/cpuinfo || echo "RISK:CPU 缺少 ssse3"; test "$(awk '/MemTotal/{print $2}' /proc/meminfo)" -ge 7340032 || echo "RISK:内存低于 7GiB"; test "$(ps -p 1 -o comm= | tr -d ' ')" = systemd; command -v docker >/dev/null || echo "INFO:安装器将安装 Docker"; umask; df -h; findmnt -no FSTYPE ` + sq(t.Request.InstallDir) + ` 2>/dev/null || findmnt -no FSTYPE /; ss -lntup 2>/dev/null | grep -E ':(443|12345|12346|1194)[[:space:]]' && exit 31 || true; echo PRECHECK_OK`
	if e := rt.remote(t, cmd); e != nil {
		rt.fail(t, "预检硬阻断: "+e.Error())
		return
	}
	rt.mu.Lock()
	for _, l := range t.Logs {
		if i := strings.Index(l, "RISK:"); i >= 0 {
			t.Warnings = append(t.Warnings, l[i+5:])
		}
	}
	t.Status = "precheck_passed"
	rt.mu.Unlock()
	rt.log(t, "预检完成")
}
func (rt *Runtime) deploy(t *Task) {
	defer wipe(t)
	x := t.Request
	rt.log(t, "阶段 1/5：创建安装目录")
	if e := rt.remote(t, "mkdir -p "+sq(x.InstallDir)); e != nil {
		rt.fail(t, "创建安装目录失败: "+e.Error())
		return
	}
	rt.log(t, "阶段 2/5：上传安装包")
	if e := rt.upload(t); e != nil {
		rt.fail(t, e.Error())
		return
	}
	remotePkg := "/tmp/dongjian-installer-" + t.ID + ".bin"
	rt.log(t, "阶段 3/5：执行安装器")
	cmd := "chmod 700 " + sq(remotePkg) + " && " + sq(remotePkg) + " --package-password=" + sq(x.PackagePassword) + " --install-path=" + sq(x.InstallDir)
	if x.NodeType == "engine" && x.Mode == "distributed" {
		cmd += " --engine-ip=" + sq(x.EngineIP) + " --mgmt-ip=" + sq(x.MgmtIP) + " --mgmt-id=" + sq(x.MgmtID)
	}
	if e := rt.remote(t, cmd); e != nil {
		rt.fail(t, "安装器失败: "+e.Error())
		return
	}
	rt.log(t, "阶段 4/5：检查容器")
	if e := rt.remote(t, "docker ps"); e != nil {
		rt.fail(t, e.Error())
		return
	}
	rt.log(t, "阶段 5/5：产品健康检查")
	health := x.InstallDir + "/minion " + map[bool]string{true: "mgmt", false: "engine"}[x.NodeType == "management"] + " health"
	if e := rt.remote(t, health); e != nil {
		rt.fail(t, "健康检查失败: "+e.Error())
		return
	}
	rt.mu.Lock()
	t.Status = "completed"
	rt.mu.Unlock()
	rt.log(t, "洞鉴部署完成")
}
func hash(t *Task, rt *Runtime) error {
	f, e := os.Open(t.Request.Package)
	if e != nil {
		return e
	}
	defer f.Close()
	h := md5.New()
	io.Copy(h, f)
	sum := hex.EncodeToString(h.Sum(nil))
	rt.log(t, "安装包 MD5: "+sum)
	base := filepath.Base(t.Request.Package)
	if m := regexp.MustCompile(`(?i)([0-9a-f]{32})`).FindString(base); m != "" && !strings.EqualFold(m, sum) {
		return fmt.Errorf("安装包 MD5 与文件名不一致")
	}
	return nil
}
func (rt *Runtime) client(t *Task) (*ssh.Client, error) {
	kp := os.Getenv("DEPLOY_KNOWN_HOSTS")
	if kp == "" {
		kp = filepath.Join(os.Getenv("HOME"), ".ssh", "known_hosts")
	}
	cb, e := sshutil.HostKeyCallback(kp)
	if e != nil {
		return nil, e
	}
	endpoint, e := sshutil.Endpoint(t.Request.Host, t.Request.SSHPort)
	if e != nil {
		return nil, e
	}
	return ssh.Dial("tcp", endpoint, &ssh.ClientConfig{User: t.Request.User, Auth: []ssh.AuthMethod{ssh.Password(t.Request.SSHPassword)}, HostKeyCallback: cb, Timeout: 15 * time.Second})
}
func (rt *Runtime) remote(t *Task, cmd string) error {
	rt.log(t, "执行: "+redact(cmd))
	c, e := rt.client(t)
	if e != nil {
		return e
	}
	defer c.Close()
	s, e := c.NewSession()
	if e != nil {
		return e
	}
	defer s.Close()
	out, _ := s.StdoutPipe()
	er, _ := s.StderrPipe()
	if e = s.Start("bash -lc " + sq(cmd)); e != nil {
		return e
	}
	var wg sync.WaitGroup
	stream := func(r io.Reader, p string) {
		defer wg.Done()
		sc := bufio.NewScanner(r)
		for sc.Scan() {
			rt.log(t, p+sc.Text())
		}
	}
	wg.Add(2)
	go stream(out, "[stdout] ")
	go stream(er, "[stderr] ")
	e = s.Wait()
	wg.Wait()
	return e
}
func (rt *Runtime) upload(t *Task) error {
	c, e := rt.client(t)
	if e != nil {
		return e
	}
	defer c.Close()
	s, e := c.NewSession()
	if e != nil {
		return e
	}
	defer s.Close()
	in, e := s.StdinPipe()
	if e != nil {
		return e
	}
	dst := "/tmp/dongjian-installer-" + t.ID + ".bin"
	if e = s.Start("cat > " + sq(dst)); e != nil {
		return e
	}
	f, e := os.Open(t.Request.Package)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = io.Copy(in, f)
	in.Close()
	if e != nil {
		return e
	}
	return s.Wait()
}
func (rt *Runtime) log(t *Task, s string) {
	rt.mu.Lock()
	t.Logs = append(t.Logs, time.Now().Format("15:04:05 ")+redact(s))
	rt.mu.Unlock()
}
func (rt *Runtime) fail(t *Task, s string) {
	rt.mu.Lock()
	t.Status = "failed"
	t.Error = redact(s)
	rt.mu.Unlock()
	rt.log(t, "失败: "+s)
}
func wipe(t *Task)       { t.Request.SSHPassword = ""; t.Request.PackagePassword = "" }
func sq(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
func redact(s string) string {
	re := regexp.MustCompile(`--package-password=('([^']|'\\'')*'|[^ ]+)`)
	return re.ReplaceAllString(s, "--package-password='[REDACTED]'")
}
