package safeline

import (
	"context"
	"deploy-platform/internal/agent"
	"fmt"
)

type Agent struct{}

func New() *Agent { return &Agent{} }
func (*Agent) Capabilities() agent.Capability {
	return agent.Capability{Product: "safeline", DisplayName: "雷池 SafeLine", Versions: []string{"23.01.014"}, Modes: []string{"reverse-proxy-single"}, NodeTypes: []string{"Software"}}
}
func (*Agent) Validate(r agent.Request) error {
	if r.Version != "23.01.014" || r.Mode != "reverse-proxy-single" {
		return fmt.Errorf("unsupported SafeLine deployment")
	}
	return nil
}
func (*Agent) Precheck(context.Context, agent.Request, agent.Logger) (agent.PrecheckResult, error) {
	return agent.PrecheckResult{}, fmt.Errorf("SafeLine legacy adapter is not connected yet")
}
func (*Agent) Deploy(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("SafeLine legacy adapter is not connected yet")
}
func (*Agent) Verify(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("SafeLine legacy adapter is not connected yet")
}
