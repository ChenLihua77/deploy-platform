package safeline

import (
	"bufio"
	"crypto/md5"
	"crypto/sha256"
	"deploy-platform/internal/credentials"
	"deploy-platform/internal/sshutil"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"html/template"
	"io"
	"net/http"
	"net/netip"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"golang.org/x/crypto/ssh"
)

type DeployRequest struct {
	Product      string `json:"product"`
	Version      string `json:"version"`
	Mode         string `json:"mode"`
	NodeType     string `json:"node_type"`
	Host         string `json:"host"`
	User         string `json:"user"`
	Package      string `json:"package"`
	Password     string `json:"password"`
	SSHPassword  string `json:"ssh_password"`
	SSHPort      string `json:"ssh_port"`
	InstallDir   string `json:"install_dir"`
	DryRun       bool   `json:"dry_run"`
	Confirmed    bool   `json:"confirmed"`
	PrecheckID   string `json:"precheck_id"`
	RiskOverride bool   `json:"risk_override"`
	RiskReason   string `json:"risk_reason"`
}
type Task struct {
	ID           string        `json:"id"`
	Request      DeployRequest `json:"request"`
	Status       string        `json:"status"`
	Logs         []string      `json:"logs"`
	Error        string        `json:"error,omitempty"`
	Started      time.Time     `json:"started"`
	Finished     *time.Time    `json:"finished,omitempty"`
	RiskWarnings []string      `json:"risk_warnings,omitempty"`
}

var store = struct {
	sync.RWMutex
	tasks       map[string]*Task
	activeHosts map[string]string
}{tasks: map[string]*Task{}, activeHosts: map[string]string{}}

var allowedHost = func(string) bool { return false }

func Register(mux *http.ServeMux, allowed func(string) bool) {
	allowedHost = allowed
	mux.HandleFunc("GET /safeline/deploy", page)
	mux.HandleFunc("POST /api/v1/safeline/deploy", create)
	mux.HandleFunc("GET /api/v1/safeline/tasks/{id}", task)
	mux.HandleFunc("POST /api/v1/safeline/tasks/{id}/retry", retry)
	mux.HandleFunc("POST /api/v1/safeline/tasks/{id}/cleanup", cleanup)
}
func page(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	template.Must(template.New("p").Parse(fixedUI)).Execute(w, nil)
}
func create(w http.ResponseWriter, r *http.Request) {
	var req DeployRequest
	if json.NewDecoder(r.Body).Decode(&req) != nil {
		http.Error(w, "invalid JSON", 400)
		return
	}
	req.SSHPort = sshutil.NormalizePort(req.SSHPort)
	var err error
	req.SSHPassword, err = credentials.Resolve(req.Host, req.SSHPort, req.User, req.SSHPassword)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	if err := validate(req); err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	if !req.DryRun {
		if !req.Confirmed {
			http.Error(w, "正式部署需要人工二次确认", http.StatusPreconditionFailed)
			return
		}
		if err := validatePrecheck(req); err != nil {
			http.Error(w, err.Error(), http.StatusPreconditionFailed)
			return
		}
	}
	id := fmt.Sprintf("%d", time.Now().UnixNano())
	t := &Task{ID: id, Request: req, Status: "queued", Started: time.Now()}
	store.Lock()
	if runningID := store.activeHosts[req.Host]; runningID != "" {
		store.Unlock()
		http.Error(w, "目标节点已有运行中的任务: "+runningID, http.StatusConflict)
		return
	}
	store.tasks[id] = t
	store.activeHosts[req.Host] = id
	store.Unlock()
	go run(t)
	writeJSON(w, publicTask(t))
}
func task(w http.ResponseWriter, r *http.Request) {
	store.RLock()
	t := store.tasks[r.PathValue("id")]
	store.RUnlock()
	if t == nil {
		http.NotFound(w, r)
		return
	}
	writeJSON(w, publicTask(t))
}
func retry(w http.ResponseWriter, r *http.Request) {
	store.RLock()
	old := store.tasks[r.PathValue("id")]
	store.RUnlock()
	if old == nil {
		http.NotFound(w, r)
		return
	}
	if !old.Request.DryRun {
		http.Error(w, "正式部署不能直接重试，请重新预检并再次人工确认", http.StatusPreconditionFailed)
		return
	}
	if old.Request.SSHPassword == "" {
		http.Error(w, "临时 SSH 密码已按安全策略清除，请在表单中重新填写后执行预检", http.StatusPreconditionFailed)
		return
	}
	store.RLock()
	running := old.Status != "failed" && old.Status != "completed" && old.Status != "dry-run"
	store.RUnlock()
	if running {
		http.Error(w, "任务仍在运行", http.StatusConflict)
		return
	}
	id := fmt.Sprintf("%d", time.Now().UnixNano())
	t := &Task{ID: id, Request: old.Request, Status: "queued", Started: time.Now()}
	store.Lock()
	if runningID := store.activeHosts[old.Request.Host]; runningID != "" {
		store.Unlock()
		http.Error(w, "目标节点已有运行中的任务: "+runningID, http.StatusConflict)
		return
	}
	store.tasks[id] = t
	store.activeHosts[old.Request.Host] = id
	store.Unlock()
	go run(t)
	writeJSON(w, publicTask(t))
}
func cleanup(w http.ResponseWriter, r *http.Request) {
	store.RLock()
	t := store.tasks[r.PathValue("id")]
	store.RUnlock()
	if t == nil {
		http.NotFound(w, r)
		return
	}
	if t.Status != "failed" && t.Status != "completed" && t.Status != "dry-run" {
		http.Error(w, "任务仍在运行，不能清理", http.StatusConflict)
		return
	}
	if err := remote(t, "rm -rf -- /tmp/safeline-installer-tmp"); err != nil {
		writeJSON(w, map[string]any{"ok": false, "message": err.Error()})
		return
	}
	log(t, "已清理远程临时目录 /tmp/safeline-installer-tmp")
	writeJSON(w, map[string]any{"ok": true, "message": "远程临时目录已清理"})
}
func publicTask(t *Task) map[string]any {
	store.RLock()
	defer store.RUnlock()
	return map[string]any{"id": t.ID, "status": t.Status, "logs": append([]string(nil), t.Logs...), "error": t.Error, "risk_warnings": append([]string(nil), t.RiskWarnings...), "started": t.Started, "finished": t.Finished, "request": map[string]any{"product": t.Request.Product, "version": t.Request.Version, "mode": t.Request.Mode, "node_type": t.Request.NodeType, "host": t.Request.Host, "user": t.Request.User, "package": t.Request.Package, "install_dir": t.Request.InstallDir, "dry_run": t.Request.DryRun}}
}
func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}
func validate(r DeployRequest) error {
	if r.Product != "safeline" || r.Version != "23.01.014" {
		return fmt.Errorf("当前 MVP 仅支持 safeline 23.01.014")
	}
	if r.Mode != "reverse-proxy-single" || r.NodeType != "Software" {
		return fmt.Errorf("当前 MVP 仅支持软件反代单机 / Software")
	}
	if r.Host == "" || r.User == "" || r.SSHPassword == "" || r.Package == "" {
		return fmt.Errorf("目标 IP、SSH 用户、临时 SSH 密码和安装包不能为空")
	}
	addr, err := netip.ParseAddr(r.Host)
	if err != nil {
		return fmt.Errorf("目标节点必须是白名单中的内网 IP 地址")
	}
	if !addr.IsPrivate() && os.Getenv("SAFELINE_ALLOW_PUBLIC_TEST_TARGET") != "true" {
		return fmt.Errorf("目标节点必须是白名单中的内网 IP 地址（公网测试需显式启用临时例外）")
	}
	if !allowedHost(r.Host) {
		return fmt.Errorf("目标节点 %s 不在 SAFELINE_ALLOWED_HOSTS 白名单中", r.Host)
	}
	if !filepath.IsAbs(r.Package) {
		return fmt.Errorf("安装包必须使用本机绝对路径")
	}
	if _, err := sshutil.Endpoint(r.Host, r.SSHPort); err != nil {
		return err
	}
	return nil
}
func loadAllowedHosts() map[string]struct{} {
	hosts := map[string]struct{}{}
	for _, host := range strings.Split(os.Getenv("SAFELINE_ALLOWED_HOSTS"), ",") {
		if host = strings.TrimSpace(host); host != "" {
			hosts[host] = struct{}{}
		}
	}
	return hosts
}
func validatePrecheck(r DeployRequest) error {
	store.RLock()
	p := store.tasks[r.PrecheckID]
	store.RUnlock()
	if p == nil || p.Status != "dry-run" || !p.Request.DryRun {
		return fmt.Errorf("正式部署前必须完成一次有效预检")
	}
	if p.Request.Host != r.Host || p.Request.SSHPort != r.SSHPort || p.Request.User != r.User || p.Request.Package != r.Package || p.Request.Product != r.Product || p.Request.Version != r.Version || p.Request.Mode != r.Mode || p.Request.NodeType != r.NodeType || defaultDir(p.Request.InstallDir) != defaultDir(r.InstallDir) {
		return fmt.Errorf("部署参数已变化，请重新执行预检")
	}
	if len(p.RiskWarnings) > 0 && (!r.RiskOverride || strings.TrimSpace(r.RiskReason) == "") {
		return fmt.Errorf("预检存在资源风险，必须提交风险确认和原因")
	}
	return nil
}
func run(t *Task) {
	defer releaseHost(t)
	defer func() { t.Request.Password = ""; t.Request.SSHPassword = "" }()
	setStatus(t, "prechecking")
	log(t, "开始部署任务（密码已脱敏）")
	if err := hashPackage(t); err != nil {
		fail(t, err)
		return
	}
	steps := []string{"id", "uname -a", "command -v minion || true", "command -v docker || true", "lscpu | grep -E 'ssse3|avx2' || true", "free -h", "df -h"}
	for _, s := range steps {
		if err := remote(t, s); err != nil {
			fail(t, err)
			return
		}
	}
	log(t, "执行强制预检：操作系统、systemd、CPU、内存和磁盘")
	if err := remote(t, precheckCommand); err != nil {
		fail(t, fmt.Errorf("环境预检未通过: %w", err))
		return
	}
	store.Lock()
	for _, line := range t.Logs {
		if i := strings.Index(line, "风险告警:"); i >= 0 {
			t.RiskWarnings = append(t.RiskWarnings, strings.TrimSpace(line[i+len("风险告警:"):]))
		}
	}
	store.Unlock()
	log(t, "预检完成：确认后将执行安装")
	if t.Request.DryRun {
		setStatus(t, "dry-run")
		finish(t)
		return
	}
	setStatus(t, "installing")
	log(t, "阶段 1/6：准备远程安装目录")
	if err := remote(t, "mkdir -p /tmp/safeline-installer-tmp /data/safeline"); err != nil {
		fail(t, err)
		return
	}
	log(t, "阶段 2/6：上传安装包")
	if err := copyPackage(t); err != nil {
		fail(t, err)
		return
	}
	log(t, "阶段 3/6：执行产品安装器（输出将实时显示）")
	installer := "chmod +x /tmp/safeline-installer-tmp/safeline-installer.bin && /tmp/safeline-installer-tmp/safeline-installer.bin -p " + shellQuote(t.Request.Password)
	if err := remote(t, installer); err != nil {
		fail(t, fmt.Errorf("阶段 3/6 产品安装器失败: %w", err))
		return
	}
	log(t, "阶段 4/6：执行安装前检查")
	if err := remote(t, "minion check run before-install"); err != nil {
		fail(t, fmt.Errorf("阶段 4/6 安装前检查失败: %w", err))
		return
	}
	log(t, "阶段 5/6：配置 SafeLine 节点")
	if err := remote(t, "minion setup -p "+shellQuote(defaultDir(t.Request.InstallDir))+" -t Software"); err != nil {
		fail(t, fmt.Errorf("阶段 5/6 节点配置失败: %w", err))
		return
	}
	log(t, "阶段 6/6：启动 minion 服务")
	if err := remote(t, "systemctl start minion"); err != nil {
		fail(t, fmt.Errorf("阶段 6/6 服务启动失败: %w", err))
		return
	}
	setStatus(t, "verifying")
	if err := remote(t, "docker ps -a --format '{{.Names}} {{.Status}}' && systemctl is-active minion"); err != nil {
		fail(t, err)
		return
	}
	setStatus(t, "completed")
	finish(t)
}
func releaseHost(t *Task) {
	store.Lock()
	if store.activeHosts[t.Request.Host] == t.ID {
		delete(store.activeHosts, t.Request.Host)
	}
	store.Unlock()
}
func hashPackage(t *Task) error {
	f, err := os.Open(t.Request.Package)
	if err != nil {
		return err
	}
	defer f.Close()
	h := sha256.New()
	m := md5.New()
	io.Copy(io.MultiWriter(h, m), f)
	log(t, "安装包 SHA256: "+hex.EncodeToString(h.Sum(nil)))
	log(t, "安装包 MD5: "+hex.EncodeToString(m.Sum(nil)))
	return nil
}
func copyPackage(t *Task) error {
	f, err := os.Open(t.Request.Package)
	if err != nil {
		return fmt.Errorf("打开安装包失败: %w", err)
	}
	defer f.Close()
	client, err := sshClient(t)
	if err != nil {
		return err
	}
	defer client.Close()
	s, err := client.NewSession()
	if err != nil {
		return fmt.Errorf("创建上传会话失败: %w", err)
	}
	defer s.Close()
	in, err := s.StdinPipe()
	if err != nil {
		return fmt.Errorf("创建上传管道失败: %w", err)
	}
	if err := s.Start("cat > /tmp/safeline-installer-tmp/safeline-installer.bin"); err != nil {
		return fmt.Errorf("启动上传失败: %w", err)
	}
	if _, err := io.Copy(in, f); err != nil {
		return fmt.Errorf("上传安装包失败: %w", err)
	}
	in.Close()
	if err := s.Wait(); err != nil {
		return fmt.Errorf("上传安装包失败: %w", err)
	}
	log(t, "安装包已上传到目标节点")
	return nil
}
func remote(t *Task, command string) error {
	log(t, "执行: "+redact(command))
	client, err := sshClient(t)
	if err != nil {
		return err
	}
	defer client.Close()
	c, err := client.NewSession()
	if err != nil {
		return fmt.Errorf("创建 SSH 会话失败: %w", err)
	}
	defer c.Close()
	stdout, err := c.StdoutPipe()
	if err != nil {
		return err
	}
	stderr, err := c.StderrPipe()
	if err != nil {
		return err
	}
	if err := c.Start("bash -lc " + shellQuote(command)); err != nil {
		return fmt.Errorf("远程命令无法启动 [%s]: %w", redact(command), err)
	}
	var wg sync.WaitGroup
	stream := func(r io.Reader, prefix string) {
		defer wg.Done()
		s := bufio.NewScanner(r)
		s.Buffer(make([]byte, 64*1024), 1024*1024)
		for s.Scan() {
			if line := strings.TrimSpace(s.Text()); line != "" {
				log(t, prefix+line)
			}
		}
		if scanErr := s.Err(); scanErr != nil {
			log(t, prefix+"日志读取失败: "+scanErr.Error())
		}
	}
	wg.Add(2)
	go stream(stdout, "[stdout] ")
	go stream(stderr, "[stderr] ")
	waitErr := c.Wait()
	wg.Wait()
	if waitErr != nil {
		return fmt.Errorf("远程命令失败 [%s]: %w（详细输出见上方日志）", redact(command), waitErr)
	}
	log(t, "完成: "+redact(command))
	return nil
}

func sshClient(t *Task) (*ssh.Client, error) {
	var auth ssh.AuthMethod
	if t.Request.SSHPassword != "" {
		auth = ssh.Password(t.Request.SSHPassword)
	} else {
		if os.Getenv("SAFELINE_SSH_KEY") == "" {
			return nil, fmt.Errorf("临时 SSH 密码为空，请重新填写后执行预检")
		}
		keyPath := os.Getenv("SAFELINE_SSH_KEY")
		if keyPath == "" {
			keyPath = filepath.Join(os.Getenv("HOME"), ".ssh", "id_ed25519")
		}
		key, err := os.ReadFile(keyPath)
		if err != nil {
			return nil, fmt.Errorf("读取 SSH 私钥失败: %w", err)
		}
		signer, err := ssh.ParsePrivateKey(key)
		if err != nil {
			return nil, fmt.Errorf("解析 SSH 私钥失败: %w", err)
		}
		auth = ssh.PublicKeys(signer)
	}
	knownPath := os.Getenv("SAFELINE_KNOWN_HOSTS")
	if knownPath == "" {
		knownPath = filepath.Join(os.Getenv("HOME"), ".ssh", "known_hosts")
	}
	hostKeyCallback, err := sshutil.HostKeyCallback(knownPath)
	if err != nil {
		return nil, fmt.Errorf("读取 SSH 主机指纹文件失败（请配置 SAFELINE_KNOWN_HOSTS）: %w", err)
	}
	config := &ssh.ClientConfig{User: t.Request.User, Auth: []ssh.AuthMethod{auth}, HostKeyCallback: hostKeyCallback, Timeout: 15 * time.Second}
	endpoint, err := sshutil.Endpoint(t.Request.Host, t.Request.SSHPort)
	if err != nil {
		return nil, err
	}
	return ssh.Dial("tcp", endpoint, config)
}
func log(t *Task, s string) {
	s = redact(s)
	store.Lock()
	t.Logs = append(t.Logs, time.Now().Format("15:04:05 ")+s)
	store.Unlock()
}
func setStatus(t *Task, s string) { store.Lock(); t.Status = s; store.Unlock() }
func fail(t *Task, e error) {
	store.Lock()
	t.Status = "failed"
	t.Error = e.Error()
	now := time.Now()
	t.Finished = &now
	store.Unlock()
	log(t, "失败: "+e.Error())
}
func finish(t *Task) { store.Lock(); now := time.Now(); t.Finished = &now; store.Unlock() }
func defaultDir(s string) string {
	if s == "" {
		return "/data/safeline"
	}
	return s
}
func shellQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
func redact(s string) string {
	if i := strings.Index(s, " -p '"); i >= 0 {
		return s[:i] + " -p '[REDACTED]'"
	}
	return s
}

// Fixed, reviewed command template derived from the 23.01.014 deployment
// manual: Ubuntu >=16.04, CentOS >=7.4, Debian >=8, 8 GiB RAM, 500 GiB disk,
// SSSE3 and AVX2. Arbitrary client-provided commands are never accepted.
const precheckCommand = `set -eu
. /etc/os-release
case "$ID" in
  ubuntu) minimum=16.04 ;;
  centos) minimum=7.4 ;;
  debian) minimum=8 ;;
  *) echo "不支持的操作系统: $ID ${VERSION_ID:-unknown}" >&2; exit 21 ;;
esac
if [ "$(printf '%s\n' "$minimum" "${VERSION_ID:-0}" | sort -V | head -n1)" != "$minimum" ]; then echo "操作系统版本过低: $ID ${VERSION_ID:-unknown}，最低 $minimum" >&2; exit 22; fi
[ "$(ps -p 1 -o comm= | tr -d ' ')" = systemd ] || { echo "PID 1 不是 systemd" >&2; exit 23; }
grep -qiE '(^|[[:space:]])ssse3([[:space:]]|$)' /proc/cpuinfo || echo "风险告警: CPU 缺少 SSSE3"
grep -qiE '(^|[[:space:]])avx2([[:space:]]|$)' /proc/cpuinfo || echo "风险告警: CPU 缺少 AVX2"
[ "$(awk '/MemTotal/{print $2}' /proc/meminfo)" -ge 8388608 ] || echo "风险告警: 内存不足 8 GiB"
[ "$(df -Pk / | awk 'NR==2{print $2}')" -ge 524288000 ] || echo "风险告警: 磁盘容量不足 500 GiB"
echo "强制环境预检通过"`

const ui = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>SafeLine 自动部署 Agent</title><style>body{font:15px system-ui;background:#f4f7fb;color:#17243a;margin:0}main{max-width:850px;margin:35px auto;padding:25px;background:white;border-radius:14px;box-shadow:0 8px 30px #1232}h1{margin-top:0}form{display:grid;grid-template-columns:1fr 1fr;gap:13px}label{display:grid;gap:5px;color:#607086}input,select,button{padding:11px;border:1px solid #ccd8e6;border-radius:8px;font:inherit}button{grid-column:1/-1;background:#1769d2;color:white;border:0;cursor:pointer;font-weight:700}.wide{grid-column:1/-1}.hint{color:#718096;font-size:13px}.log{white-space:pre-wrap;background:#0d1726;color:#d8e7f8;padding:15px;border-radius:9px;min-height:100px;margin-top:20px}</style><main><h1>SafeLine 自动部署 Agent</h1><p class="hint">当前支持：SL-20 / 23.01.014 / 软件反代单机。首次建议勾选预演。</p><form id="f"><label>产品类型<select name="product"><option value="safeline">雷池 SafeLine</option></select></label><label>产品版本<select name="version"><option>23.01.014</option></select></label><label>部署模式<select name="mode"><option value="reverse-proxy-single">软件反代单机</option><option disabled>软件反代集群（后续）</option><option disabled>软件嵌入式集群（后续）</option><option disabled>流量镜像（后续）</option></select></label><label>节点安装类型<select name="node_type"><option>Software</option></select></label><label>目标机器 IP<input name="host" placeholder="10.0.0.10" required></label><label>SSH 用户<input name="user" value="root" required></label><label class="wide">安装包绝对路径<input name="package" placeholder="/path/safeline-installer.bin" required></label><label>安装包密码<input name="password" type="password" autocomplete="new-password" required></label><label>安装目录<input name="install_dir" value="/data/safeline"></label><label class="wide"><input name="dry_run" type="checkbox" checked> 仅预演（只做预检，不安装）</label><button>创建部署任务</button></form><div id="status" class="hint"></div><pre id="log" class="log">等待任务…</pre></main><script>const f=document.querySelector('#f');f.onsubmit=async e=>{e.preventDefault();let o=Object.fromEntries(new FormData(f));o.dry_run=o.dry_run==='on';let r=await fetch('/api/deploy',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});let d=await r.json();if(!r.ok){status.textContent=d.detail||d;return}status.textContent='任务 '+d.id+' 已创建';let timer=setInterval(async()=>{let x=await fetch('/api/tasks/'+d.id).then(r=>r.json());status.textContent=x.status+(x.error?'：'+x.error:'');log.textContent=x.logs.join('\n');if(['completed','failed','dry-run'].includes(x.status))clearInterval(timer)},800)}</script></html>`
