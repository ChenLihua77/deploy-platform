package quanxi

import (
	"context"
	"fmt"
	"path/filepath"
	"strings"

	"deploy-platform/internal/agent"
)

type Agent struct{}

func New() *Agent { return &Agent{} }

func (*Agent) Capabilities() agent.Capability {
	return agent.Capability{
		Product:     "quanxi",
		DisplayName: "全悉（T-Answer）",
		Versions:    []string{"26.04.001"},
		Modes:       []string{"software-single"},
		NodeTypes:   []string{"management"},
	}
}

func (*Agent) Validate(r agent.Request) error {
	if r.Product != "quanxi" {
		return fmt.Errorf("产品类型必须为 quanxi")
	}
	if r.Version != "26.04.001" {
		return fmt.Errorf("当前仅适配 Answer-26.04.001")
	}
	if r.Mode != "software-single" || r.NodeType != "management" {
		return fmt.Errorf("当前仅支持软件版单机管理节点")
	}
	if strings.TrimSpace(r.Host) == "" || strings.TrimSpace(r.User) == "" {
		return fmt.Errorf("目标节点和 SSH 用户不能为空")
	}
	if !filepath.IsAbs(r.Package) {
		return fmt.Errorf("安装包必须使用本机绝对路径")
	}
	if r.InstallDir == "" || !filepath.IsAbs(r.InstallDir) {
		return fmt.Errorf("安装目录必须使用绝对路径")
	}
	return nil
}

func (*Agent) Precheck(context.Context, agent.Request, agent.Logger) (agent.PrecheckResult, error) {
	return agent.PrecheckResult{}, fmt.Errorf("全悉执行器尚未启用，请使用 26.04.001 安装包验证 install.sh")
}
func (*Agent) Deploy(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("全悉执行器尚未启用，请使用 26.04.001 安装包验证 install.sh")
}
func (*Agent) Verify(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("全悉健康检查步骤尚需根据 26.04.001 安装包确认")
}
