package quanxi

import (
	"archive/zip"
	"bufio"
	"deploy-platform/internal/credentials"
	"deploy-platform/internal/sshutil"
	"encoding/json"
	"fmt"
	"golang.org/x/crypto/ssh"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type DeployRequest struct {
	Version      string `json:"version"`
	Host         string `json:"host"`
	User         string `json:"user"`
	SSHPassword  string `json:"ssh_password"`
	SSHPort      string `json:"ssh_port"`
	Package      string `json:"package"`
	InstallDir   string `json:"install_dir"`
	PrecheckID   string `json:"precheck_id"`
	RiskReason   string `json:"risk_reason"`
	Confirmed    bool   `json:"confirmed"`
	RiskOverride bool   `json:"risk_override"`
}
type Task struct {
	ID, Status, Error string
	Logs, Warnings    []string
	Request           DeployRequest
}
type Runtime struct {
	mu      sync.RWMutex
	tasks   map[string]*Task
	allowed func(string) bool
}

func NewRuntime(a func(string) bool) *Runtime { return &Runtime{tasks: map[string]*Task{}, allowed: a} }
func (rt *Runtime) Register(m *http.ServeMux) {
	m.HandleFunc("POST /api/v1/quanxi/precheck", rt.preAPI)
	m.HandleFunc("POST /api/v1/quanxi/deploy", rt.depAPI)
	m.HandleFunc("GET /api/v1/quanxi/tasks/{id}", rt.getAPI)
}
func decode(r *http.Request) (DeployRequest, error) {
	var x DeployRequest
	e := json.NewDecoder(r.Body).Decode(&x)
	if x.InstallDir == "" {
		x.InstallDir = "/data/jupiter"
	}
	x.SSHPort = sshutil.NormalizePort(x.SSHPort)
	if e == nil {
		x.SSHPassword, e = credentials.Resolve(x.Host, x.SSHPort, x.User, x.SSHPassword)
	}
	return x, e
}
func (rt *Runtime) valid(x DeployRequest) error {
	if !rt.allowed(x.Host) {
		return fmt.Errorf("目标节点不在平台白名单中")
	}
	if x.Version != "26.04.001" {
		return fmt.Errorf("当前只支持 26.04.001")
	}
	if x.User == "" || x.SSHPassword == "" || !filepath.IsAbs(x.Package) || !filepath.IsAbs(x.InstallDir) {
		return fmt.Errorf("SSH 信息、安装包和绝对安装目录不能为空")
	}
	if _, err := sshutil.Endpoint(x.Host, x.SSHPort); err != nil {
		return err
	}
	if filepath.Ext(x.Package) != ".zip" {
		return fmt.Errorf("安装包必须是 ZIP")
	}
	return nil
}
func (rt *Runtime) preAPI(w http.ResponseWriter, r *http.Request) {
	x, e := decode(r)
	if e != nil || rt.valid(x) != nil {
		if e == nil {
			e = rt.valid(x)
		}
		http.Error(w, e.Error(), 400)
		return
	}
	t := rt.new(x, "prechecking")
	go rt.precheck(t)
	out(w, t)
}
func (rt *Runtime) depAPI(w http.ResponseWriter, r *http.Request) {
	x, e := decode(r)
	if e != nil || rt.valid(x) != nil {
		if e == nil {
			e = rt.valid(x)
		}
		http.Error(w, e.Error(), 400)
		return
	}
	if !x.Confirmed {
		http.Error(w, "正式安装需要二次确认", 412)
		return
	}
	rt.mu.RLock()
	p := rt.tasks[x.PrecheckID]
	rt.mu.RUnlock()
	if p == nil || p.Status != "precheck_passed" || !same(p.Request, x) {
		http.Error(w, "必须先完成相同参数预检", 412)
		return
	}
	if len(p.Warnings) > 0 && (!x.RiskOverride || strings.TrimSpace(x.RiskReason) == "") {
		http.Error(w, "存在风险项，必须确认原因", 412)
		return
	}
	t := rt.new(x, "installing")
	go rt.deploy(t)
	out(w, t)
}
func (rt *Runtime) getAPI(w http.ResponseWriter, r *http.Request) {
	rt.mu.RLock()
	t := rt.tasks[r.PathValue("id")]
	rt.mu.RUnlock()
	if t == nil {
		http.NotFound(w, r)
		return
	}
	out(w, t)
}
func out(w http.ResponseWriter, t *Task) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"id": t.ID, "status": t.Status, "error": t.Error, "logs": t.Logs, "warnings": t.Warnings})
}
func (rt *Runtime) new(x DeployRequest, s string) *Task {
	t := &Task{ID: fmt.Sprint(time.Now().UnixNano()), Status: s, Request: x}
	rt.mu.Lock()
	rt.tasks[t.ID] = t
	rt.mu.Unlock()
	return t
}
func same(a, b DeployRequest) bool {
	return a.Version == b.Version && a.Host == b.Host && a.SSHPort == b.SSHPort && a.User == b.User && a.Package == b.Package && a.InstallDir == b.InstallDir
}
func zipCheck(path string) error {
	z, e := zip.OpenReader(path)
	if e != nil {
		return e
	}
	defer z.Close()
	for _, f := range z.File {
		if filepath.Base(f.Name) == "install.sh" {
			return nil
		}
	}
	return fmt.Errorf("ZIP 中未找到 install.sh")
}
func (rt *Runtime) precheck(t *Task) {
	defer wipe(t)
	rt.log(t, "开始全悉单机预检")
	if e := zipCheck(t.Request.Package); e != nil {
		rt.fail(t, e.Error())
		return
	}
	rt.log(t, "ZIP 完整且包含 install.sh")
	cmd := `set -e;. /etc/os-release; echo "OS=$ID $VERSION_ID"; k=$(uname -r|cut -d- -f1); echo "KERNEL=$k"; case "$k" in 4.15.0-13[7-9]|4.15.0-14[0-4]) exit 21;; esac; [ "$(nproc)" -ge 8 ]||echo "RISK:CPU 少于8线程"; [ "$(awk '/MemTotal/{print $2}' /proc/meminfo)" -ge 33554432 ]||echo "RISK:内存少于32GiB"; [ "$(df -Pk /data 2>/dev/null|awk 'NR==2{print $2}'||echo 0)" -ge 268435456 ]||echo "RISK:/data 容量少于256GiB"; command -v unzip >/dev/null; if command -v docker >/dev/null;then docker version --format '{{.Server.APIVersion}}';fi; echo PRECHECK_OK`
	if e := rt.remote(t, cmd); e != nil {
		rt.fail(t, "预检硬阻断: "+e.Error())
		return
	}
	rt.mu.Lock()
	for _, l := range t.Logs {
		if i := strings.Index(l, "RISK:"); i >= 0 {
			t.Warnings = append(t.Warnings, l[i+5:])
		}
	}
	t.Status = "precheck_passed"
	rt.mu.Unlock()
	rt.log(t, "预检完成")
}
func (rt *Runtime) deploy(t *Task) {
	defer wipe(t)
	pkg := "/tmp/quanxi-" + t.ID + ".zip"
	rt.log(t, "阶段1/4：上传ZIP")
	if e := rt.upload(t, pkg); e != nil {
		rt.fail(t, e.Error())
		return
	}
	rt.log(t, "阶段2/4：解压安装包")
	cmd := "mkdir -p " + q(t.Request.InstallDir) + " && unzip -q " + q(pkg) + " -d " + q(t.Request.InstallDir)
	if e := rt.remote(t, cmd); e != nil {
		rt.fail(t, e.Error())
		return
	}
	rt.log(t, "阶段3/4：执行 install.sh")
	cmd = "script=$(find " + q(t.Request.InstallDir) + " -name install.sh -type f | head -n1); test -n \"$script\"; cd \"$(dirname \"$script\")\"; chmod 700 ./install.sh; ./install.sh"
	if e := rt.remote(t, cmd); e != nil {
		rt.fail(t, "install.sh失败: "+e.Error())
		return
	}
	rt.log(t, "阶段4/4：检查容器")
	if e := rt.remote(t, "docker ps"); e != nil {
		rt.fail(t, "容器检查失败: "+e.Error())
		return
	}
	rt.mu.Lock()
	t.Status = "completed"
	rt.mu.Unlock()
	rt.log(t, "安装完成；请按维护窗口人工确认并重启服务器")
}
func (rt *Runtime) client(t *Task) (*ssh.Client, error) {
	kp := os.Getenv("DEPLOY_KNOWN_HOSTS")
	if kp == "" {
		kp = filepath.Join(os.Getenv("HOME"), ".ssh", "known_hosts")
	}
	cb, e := sshutil.HostKeyCallback(kp)
	if e != nil {
		return nil, e
	}
	endpoint, e := sshutil.Endpoint(t.Request.Host, t.Request.SSHPort)
	if e != nil {
		return nil, e
	}
	return ssh.Dial("tcp", endpoint, &ssh.ClientConfig{User: t.Request.User, Auth: []ssh.AuthMethod{ssh.Password(t.Request.SSHPassword)}, HostKeyCallback: cb, Timeout: 15 * time.Second})
}
func (rt *Runtime) remote(t *Task, cmd string) error {
	rt.log(t, "执行: "+cmd)
	c, e := rt.client(t)
	if e != nil {
		return e
	}
	defer c.Close()
	s, e := c.NewSession()
	if e != nil {
		return e
	}
	defer s.Close()
	o, _ := s.StdoutPipe()
	er, _ := s.StderrPipe()
	if e = s.Start("bash -lc " + q(cmd)); e != nil {
		return e
	}
	var wg sync.WaitGroup
	fn := func(r io.Reader, p string) {
		defer wg.Done()
		sc := bufio.NewScanner(r)
		for sc.Scan() {
			rt.log(t, p+sc.Text())
		}
	}
	wg.Add(2)
	go fn(o, "[stdout] ")
	go fn(er, "[stderr] ")
	e = s.Wait()
	wg.Wait()
	return e
}
func (rt *Runtime) upload(t *Task, dst string) error {
	c, e := rt.client(t)
	if e != nil {
		return e
	}
	defer c.Close()
	s, e := c.NewSession()
	if e != nil {
		return e
	}
	defer s.Close()
	in, _ := s.StdinPipe()
	if e = s.Start("cat > " + q(dst)); e != nil {
		return e
	}
	f, e := os.Open(t.Request.Package)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = io.Copy(in, f)
	in.Close()
	if e != nil {
		return e
	}
	return s.Wait()
}
func (rt *Runtime) log(t *Task, s string) {
	rt.mu.Lock()
	t.Logs = append(t.Logs, time.Now().Format("15:04:05 ")+s)
	rt.mu.Unlock()
}
func (rt *Runtime) fail(t *Task, s string) {
	rt.mu.Lock()
	t.Status = "failed"
	t.Error = s
	rt.mu.Unlock()
	rt.log(t, "失败: "+s)
}
func wipe(t *Task)      { t.Request.SSHPassword = "" }
func q(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
