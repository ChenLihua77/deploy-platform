package diting

import (
	"archive/zip"
	"deploy-platform/internal/credentials"
	"deploy-platform/internal/sshutil"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type DeployRequest struct {
	Version, Host, User, SSHPassword, SSHPort, Package, PackagePassword string
	InstallDir, HoneypotPackage, HoneypotMode, PrecheckID               string
	Confirmed                                                           bool
}

type Task struct {
	ID, Status, Error string
	Logs              []string
	Request           DeployRequest
}

type Runtime struct {
	mu      sync.RWMutex
	tasks   map[string]*Task
	allowed func(string) bool
}

func NewRuntime(allowed func(string) bool) *Runtime {
	return &Runtime{tasks: map[string]*Task{}, allowed: allowed}
}

func (rt *Runtime) Register(m *http.ServeMux) {
	m.HandleFunc("POST /api/v1/diting/precheck", rt.precheckAPI)
	m.HandleFunc("POST /api/v1/diting/deploy", rt.deployAPI)
	m.HandleFunc("GET /api/v1/diting/tasks/{id}", rt.taskAPI)
}

func decode(r *http.Request) (DeployRequest, error) {
	var wire struct {
		Version         string `json:"version"`
		Host            string `json:"host"`
		User            string `json:"user"`
		SSHPassword     string `json:"ssh_password"`
		SSHPort         string `json:"ssh_port"`
		Package         string `json:"package"`
		PackagePassword string `json:"package_password"`
		InstallDir      string `json:"install_dir"`
		HoneypotPackage string `json:"honeypot_package"`
		HoneypotMode    string `json:"honeypot_mode"`
		PrecheckID      string `json:"precheck_id"`
		Confirmed       bool   `json:"confirmed"`
	}
	err := json.NewDecoder(r.Body).Decode(&wire)
	port := sshutil.NormalizePort(wire.SSHPort)
	password := wire.SSHPassword
	if err == nil {
		password, err = credentials.Resolve(wire.Host, port, wire.User, password)
	}
	return DeployRequest{wire.Version, wire.Host, wire.User, password, port, wire.Package, wire.PackagePassword, wire.InstallDir, wire.HoneypotPackage, wire.HoneypotMode, wire.PrecheckID, wire.Confirmed}, err
}

func (rt *Runtime) validate(x DeployRequest) error {
	if !rt.allowed(x.Host) {
		return fmt.Errorf("目标节点不在平台白名单中")
	}
	if x.Version != "DS-S40-25.12.001" {
		return fmt.Errorf("当前仅支持 DS-S40-25.12.001")
	}
	if x.User == "" || x.SSHPassword == "" || x.PackagePassword == "" {
		return fmt.Errorf("SSH 用户、SSH 密码和安装包密码不能为空")
	}
	if _, err := sshutil.Endpoint(x.Host, x.SSHPort); err != nil {
		return err
	}
	if !filepath.IsAbs(x.Package) || !filepath.IsAbs(x.InstallDir) {
		return fmt.Errorf("安装包和安装目录必须使用绝对路径")
	}
	if x.HoneypotMode != "sw" && x.HoneypotMode != "sw+vm" {
		return fmt.Errorf("蜜罐模式必须为 sw 或 sw+vm")
	}
	if x.HoneypotPackage != "" && !filepath.IsAbs(x.HoneypotPackage) {
		return fmt.Errorf("蜜罐安装包必须使用绝对路径")
	}
	return nil
}

func (rt *Runtime) precheckAPI(w http.ResponseWriter, r *http.Request) {
	x, err := decode(r)
	if err == nil {
		err = rt.validate(x)
	}
	if err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	t := rt.newTask(x, "prechecking")
	go rt.precheck(t)
	rt.output(w, t)
}

func (rt *Runtime) deployAPI(w http.ResponseWriter, r *http.Request) {
	x, err := decode(r)
	if err == nil {
		err = rt.validate(x)
	}
	if err != nil {
		http.Error(w, err.Error(), 400)
		return
	}
	if !x.Confirmed {
		http.Error(w, "正式安装需要二次确认", 412)
		return
	}
	rt.mu.RLock()
	p := rt.tasks[x.PrecheckID]
	rt.mu.RUnlock()
	if p == nil || p.Status != "precheck_passed" || !same(p.Request, x) {
		http.Error(w, "必须先完成相同参数预检", 412)
		return
	}
	http.Error(w, "谛听正式安装尚未激活：必须先完成实际安装介质与交互参数验证", 412)
}

func (rt *Runtime) taskAPI(w http.ResponseWriter, r *http.Request) {
	rt.mu.RLock()
	t := rt.tasks[r.PathValue("id")]
	rt.mu.RUnlock()
	if t == nil {
		http.NotFound(w, r)
		return
	}
	rt.output(w, t)
}

func (rt *Runtime) precheck(t *Task) {
	rt.log(t, "开始谛听安装介质预检")
	if _, err := os.Stat(t.Request.Package); err != nil {
		rt.fail(t, "系统安装包不可读: "+err.Error())
		return
	}
	if t.Request.HoneypotPackage != "" {
		if _, err := os.Stat(t.Request.HoneypotPackage); err != nil {
			rt.fail(t, "蜜罐安装包不可读: "+err.Error())
			return
		}
	}
	if strings.EqualFold(filepath.Ext(t.Request.Package), ".zip") {
		z, err := zip.OpenReader(t.Request.Package)
		if err != nil {
			rt.fail(t, "系统 ZIP 无法读取: "+err.Error())
			return
		}
		defer z.Close()
		found := false
		for _, f := range z.File {
			n := strings.ToLower(filepath.Base(f.Name))
			if strings.Contains(n, "installer") || n == "checkenv" || n == "install.sh" {
				found = true
				break
			}
		}
		if !found {
			rt.fail(t, "系统 ZIP 未发现 checkEnv、installer 或 install.sh")
			return
		}
	}
	rt.log(t, "本地介质可读，结构检查通过")
	rt.log(t, "远程环境检查暂未激活：需先确认 DS-S40-25.12.001 实际介质结构与健康验收标准")
	rt.mu.Lock()
	t.Status = "precheck_blocked"
	t.Error = "安装介质尚未完成版本验证，禁止进入正式安装"
	t.Request.SSHPassword = ""
	t.Request.PackagePassword = ""
	rt.mu.Unlock()
}

func same(a, b DeployRequest) bool {
	return a.Version == b.Version && a.Host == b.Host && a.SSHPort == b.SSHPort && a.User == b.User && a.Package == b.Package && a.InstallDir == b.InstallDir && a.HoneypotPackage == b.HoneypotPackage && a.HoneypotMode == b.HoneypotMode
}
func (rt *Runtime) newTask(x DeployRequest, status string) *Task {
	t := &Task{ID: fmt.Sprint(time.Now().UnixNano()), Status: status, Request: x}
	rt.mu.Lock()
	rt.tasks[t.ID] = t
	rt.mu.Unlock()
	return t
}
func (rt *Runtime) log(t *Task, line string) {
	rt.mu.Lock()
	t.Logs = append(t.Logs, time.Now().Format("15:04:05 ")+line)
	rt.mu.Unlock()
}
func (rt *Runtime) fail(t *Task, msg string) {
	rt.mu.Lock()
	t.Status = "failed"
	t.Error = msg
	t.Request.SSHPassword = ""
	t.Request.PackagePassword = ""
	rt.mu.Unlock()
	rt.log(t, "失败: "+msg)
}
func (rt *Runtime) output(w http.ResponseWriter, t *Task) {
	rt.mu.RLock()
	defer rt.mu.RUnlock()
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"id": t.ID, "status": t.Status, "error": t.Error, "logs": t.Logs})
}
