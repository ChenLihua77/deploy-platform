package diting

import (
	"context"
	"deploy-platform/internal/agent"
	"fmt"
	"path/filepath"
	"strings"
)

type Agent struct{}

func New() *Agent { return &Agent{} }
func (*Agent) Capabilities() agent.Capability {
	return agent.Capability{Product: "diting", DisplayName: "谛听（D-Sensor）伪装欺骗系统", Versions: []string{"DS-S40-25.12.001"}, Modes: []string{"software", "online-agent", "offline-agent"}, NodeTypes: []string{"management", "linux-agent", "windows-agent", "multi-nic-agent"}}
}
func (*Agent) Validate(r agent.Request) error {
	if r.Product != "diting" {
		return fmt.Errorf("产品类型必须为 diting")
	}
	if r.Version != "DS-S40-25.12.001" {
		return fmt.Errorf("当前仅适配 DS-S40-25.12.001")
	}
	if r.Mode != "software" && r.Mode != "online-agent" && r.Mode != "offline-agent" {
		return fmt.Errorf("部署模式无效")
	}
	switch r.NodeType {
	case "management", "linux-agent", "windows-agent", "multi-nic-agent":
	default:
		return fmt.Errorf("节点类型无效")
	}
	if strings.TrimSpace(r.Host) == "" || strings.TrimSpace(r.User) == "" {
		return fmt.Errorf("目标节点和用户不能为空")
	}
	if r.NodeType == "management" && !filepath.IsAbs(r.InstallDir) {
		return fmt.Errorf("管理节点安装目录必须是绝对路径")
	}
	return nil
}
func (*Agent) Precheck(context.Context, agent.Request, agent.Logger) (agent.PrecheckResult, error) {
	return agent.PrecheckResult{}, fmt.Errorf("谛听执行器待安装介质验证")
}
func (*Agent) Deploy(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("谛听执行器待安装介质验证")
}
func (*Agent) Verify(context.Context, agent.Request, agent.Logger) error {
	return fmt.Errorf("谛听健康检查解析器待实现")
}
