package main

import (
	"deploy-platform/internal/credentials"
	"deploy-platform/internal/nodes"
	"deploy-platform/internal/registry"
	"deploy-platform/products/diting"
	"deploy-platform/products/dongjian"
	"deploy-platform/products/muyun"
	"deploy-platform/products/quanxi"
	"deploy-platform/products/safeline"
	"encoding/json"
	"html/template"
	"log"
	"net/http"
	"os"
	"path/filepath"
)

func main() {
	r := registry.New()
	if err := r.Register(safeline.New()); err != nil {
		log.Fatal(err)
	}
	if err := r.Register(dongjian.New()); err != nil {
		log.Fatal(err)
	}
	if err := r.Register(muyun.New()); err != nil {
		log.Fatal(err)
	}
	if err := r.Register(quanxi.New()); err != nil {
		log.Fatal(err)
	}
	if err := r.Register(diting.New()); err != nil {
		log.Fatal(err)
	}
	nodeStore, err := nodes.NewStore(filepath.Join("data", "nodes.json"), os.Getenv("DEPLOY_ALLOW_PUBLIC_TEST_TARGET") == "true")
	if err != nil {
		log.Fatal(err)
	}
	dongjianRuntime := dongjian.NewRuntime(nodeStore.Contains)
	muyunRuntime := muyun.NewRuntime(nodeStore.Contains)
	quanxiRuntime := quanxi.NewRuntime(nodeStore.Contains)
	ditingRuntime := diting.NewRuntime(nodeStore.Contains)
	mux := http.NewServeMux()
	safeline.Register(mux, nodeStore.Contains)
	mux.HandleFunc("GET /", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		template.Must(template.New("platform").Parse(platformUI)).Execute(w, nil)
	})
	mux.HandleFunc("GET /dongjian/deploy", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		template.Must(template.New("dongjian").Parse(dongjianUI)).Execute(w, nil)
	})
	mux.HandleFunc("GET /muyun/deploy", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		template.Must(template.New("muyun").Parse(muyunUI)).Execute(w, nil)
	})
	mux.HandleFunc("GET /quanxi/deploy", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		template.Must(template.New("quanxi").Parse(quanxiUI)).Execute(w, nil)
	})
	mux.HandleFunc("GET /diting/deploy", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		template.Must(template.New("diting").Parse(ditingUI)).Execute(w, nil)
	})
	mux.HandleFunc("GET /health", func(w http.ResponseWriter, _ *http.Request) {
		json.NewEncoder(w).Encode(map[string]any{"ok": true, "agents": len(r.Capabilities()), "credential_storage": credentials.Enabled()})
	})
	mux.HandleFunc("GET /api/v1/products", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(r.Capabilities())
	})
	mux.HandleFunc("GET /api/v1/nodes", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(nodeStore.List())
	})
	mux.HandleFunc("POST /api/v1/nodes", func(w http.ResponseWriter, req *http.Request) {
		var n nodes.Node
		if err := json.NewDecoder(req.Body).Decode(&n); err != nil {
			http.Error(w, "请求格式错误", 400)
			return
		}
		if err := nodeStore.Add(n); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		w.WriteHeader(http.StatusCreated)
		json.NewEncoder(w).Encode(n)
	})
	mux.HandleFunc("DELETE /api/v1/nodes/{ip}", func(w http.ResponseWriter, req *http.Request) {
		if err := nodeStore.Delete(req.PathValue("ip")); err != nil {
			http.Error(w, err.Error(), 400)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	})
	mux.HandleFunc("GET /api/v1/audit", func(w http.ResponseWriter, _ *http.Request) { json.NewEncoder(w).Encode(nodeStore.Audit()) })
	mux.HandleFunc("DELETE /api/v1/audit", func(w http.ResponseWriter, req *http.Request) {
		var payload struct {
			All     bool          `json:"all"`
			Entries []nodes.Audit `json:"entries"`
		}
		if err := json.NewDecoder(req.Body).Decode(&payload); err != nil {
			http.Error(w, "请求格式错误", http.StatusBadRequest)
			return
		}
		if !payload.All && len(payload.Entries) == 0 {
			http.Error(w, "请选择需要删除的审计日志", http.StatusBadRequest)
			return
		}
		deleted, err := nodeStore.DeleteAudit(payload.Entries, payload.All)
		if err != nil {
			http.Error(w, "保存审计日志失败", http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]int{"deleted": deleted})
	})
	dongjianRuntime.Register(mux)
	muyunRuntime.Register(mux)
	quanxiRuntime.Register(mux)
	ditingRuntime.Register(mux)
	log.Println("deploy controller: http://127.0.0.1:18090")
	log.Fatal(http.ListenAndServe("127.0.0.1:18090", mux))
}
