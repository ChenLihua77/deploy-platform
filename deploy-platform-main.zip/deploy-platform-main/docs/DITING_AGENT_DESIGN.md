# 谛听（D-Sensor）DS-S40-25.12.001 Agent 设计

依据《谛听（D-sensor）伪装欺骗系统软件部署手册 DS-S40-25.12.0 V1.0》。发版目录标记 `25.12.001`，手册标题标记 `25.12.0`，平台以发版版本 `DS-S40-25.12.001` 注册，启用执行器前需核对实际安装包版本。

## 能力模型

- 软件管理节点 `management`。
- Linux 探针 `linux-agent`。
- Windows 探针 `windows-agent`。
- 多网口硬件探针 `multi-nic-agent`。
- 探针模式：在线、离线。多网口的 VLAN/IP 配置属于安装后的业务配置，不由 Agent 自动修改。
- 首期不支持升级、回滚、卸载和自动部署虚拟机蜜罐扩展。

## 管理节点安装计划

```text
环境预检
→ 上传系统 ZIP、蜜罐 ZIP 和密码
→ 解压蜜罐包并执行 install.sh
→ 解压系统 ZIP
→ 执行 d-sensor-4-software-installer*.bin -C /data/d-sensor
→ 执行交互式 installer（sw 或 sw+vm 必须由结构化选项决定）
→ docker ps -a 全部为 Up
→ 执行 /data/generate_preset.sh /data/d-sensor
→ Web 与模板人工验收
```

管理节点安装需要两类安装介质，不能复用单安装包表单。安装器交互选项必须明确建模为 `software` 或 `software-vm`，不能由 Agent 猜测。

## 管理节点预检

硬阻断：

- 操作系统、SSH、白名单或主机指纹不符合要求。
- 内核低于 3.10.0-514，或构建时间早于 2017。
- Docker 存在但低于 20.10.17，Storage Driver 不是 overlay/overlay2。
- 安装分区或 `/var/lib/docker` 不是 ext4。
- `/var/lib/docker` 可用空间低于 80 GB。
- 缺少 unzip 或 systemd。
- 安装包无法解压，或缺少 checkEnv、BIN、installer/install.sh。

风险告警：

- umask 不是 022、UTC 时间异常、SELinux/Firewalld 未关闭。
- 管理节点资源低于所选型号要求。
- 安装时无法联网。

Agent 只检查并报告防火墙/SELinux，不自动关闭，遵守“不自动修改网络配置”的平台边界。

## 探针依赖

- Linux 探针最低 1 CPU、2 GB 内存、20/50 GB 磁盘。
- 运行必须访问管理节点 TCP 1337。
- 在线安装需要访问 TCP 443 或 1338。
- 在线安装 Token 是敏感字段，不持久化、不写日志；命令必须来自平台固定模板。
- Windows 安装需要独立执行器，不通过 Linux SSH 执行。

## 待启用条件

1. 提供 DS-S40-25.12.001 系统 ZIP、蜜罐 ZIP 和解压密码。
2. 只读检查 ZIP 内的 checkEnv、BIN、installer 与 install.sh。
3. 明确产品型号和是否启用虚拟机蜜罐模块。
4. 确认管理 Web 端口、容器健康判断和模板加载成功标志。
5. 在授权测试节点完成一次预检和首次安装验证。
