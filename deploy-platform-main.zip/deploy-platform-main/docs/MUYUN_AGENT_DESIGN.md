# 牧云（CloudWalker）自动部署 Agent 设计

依据《牧云（CloudWalker）部署安装手册 V1.0》。当前完成产品注册、能力建模和安全边界，尚未启用真实执行器。

## 能力划分

- 服务端单机部署：`.bin` 安装包，默认目录 `/data/cloudwalker`。
- 服务端 K8s 集群部署：K3s + Ansible + 应用包，属于高风险独立工作流。
- Linux 探针安装：由管理平台生成安装脚本；需限制批量速度不超过每分钟 10 台。
- Windows 探针安装：需单独的 WinRM/NTLM 执行器，不复用 Linux SSH 执行器。
- 首期不支持升级、回滚、探针卸载和集群数据盘自动格式化。

## 单机管理端流程

```text
白名单与 SSH 验证
→ 安装包 MD5 校验
→ 操作系统、内核、资源与网络预检
→ 风险确认和二次确认
→ 创建安装目录
→ 上传 cloudwalker.bin
→ chmod +x
→ 以标准输入方式传递解压密码并执行 `cloudwalker.bin -C /data/cloudwalker`
→ 检查 minion 与容器状态
→ 验证 HTTPS 443 和探针通信端口
→ 生成部署报告
```

## 单机预检

硬阻断：

- 未通过平台白名单、SSH 或主机指纹校验。
- 内核低于 `3.10.0-862`。
- ARM 使用 64K page size 内核；25.03.x 及以上 ARM CPU 缺少 `lrcpc`。
- 安装包 MD5 不匹配。
- `/var` 可用空间低于 50 GB。
- 443、50051、8000、3399 等必要端口冲突。
- 安装目录不是绝对路径或位于受保护/不推荐目录。

风险告警：

- CPU 少于 4 核、内存少于 16 GB、磁盘少于 200 GB。
- SELinux、防火墙、Swap 未关闭，umask 不是 0022。
- Docker 低于 20.10 或由 Snap 安装。
- 时区不是 CST/Asia/Shanghai，或时间同步状态异常。

Agent 默认只检查并报告 SELinux、防火墙、Swap 和系统配置，不自动修改，避免超出既定的网络与系统变更边界。

## K8s 集群边界

集群手册包含格式化数据盘、挂载、关闭防火墙、禁用 Swap/SELinux、修改 sysctl/limits、批量重启和 Ansible 密码清单。这些动作具有破坏性，必须设计为独立工作流并逐项人工确认，不能复用单机“一键安装”。

以下能力在完成专项安全评审前保持禁用：

- `mkfs.xfs -f` 数据盘格式化。
- 自动修改 `/etc/fstab`、`sysctl.conf`、`limits.conf`。
- 自动关闭防火墙或批量重启节点。
- 关闭 Ansible 主机指纹校验。
- 在 inventory 文件中明文持久化 SSH 密码。

## 验收标准

- 管理平台 `https://{server_ip}/` 可访问。
- minion 与 Docker Compose 服务正常。
- 443、50051、8000、3399 的监听符合部署参数。
- License 上传和 admin 首次登录属于部署后的人工业务验收，不由 Agent 自动操作。
