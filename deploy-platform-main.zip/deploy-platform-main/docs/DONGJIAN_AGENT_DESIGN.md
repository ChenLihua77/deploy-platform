# 洞鉴（X-Ray）自动部署 Agent 设计

依据《洞鉴（X-Ray）安全评估系统部署安装手册（25.04.0~25.12.0 系列）V1.1》设计。当前阶段只注册能力和参数约束，不执行真实安装。

## 支持边界

- 产品版本：25.04.0~25.12.0 系列，但每个具体版本必须经过安装包与命令模板适配后单独启用。
- 部署模式：单机 `standalone`、分布式 `distributed`。
- 节点类型：管理节点 `management`、引擎节点 `engine`。
- 部署顺序：管理节点必须先于引擎节点；单机模式两类节点必须使用同一安装目录。
- 首期只做首次安装，不开放升级、自动卸载、网络修改和预检查绕过。
- 禁止启用安装器参数 `pre-check-disabled` 和 `pre-check-ignore-error`。

## 编排流程

```text
创建部署计划
→ 管理节点预检
→ 风险确认与二次确认
→ 上传并核对管理包 MD5
→ 安装管理节点
→ docker ps + minion mgmt health
→ 获取并校验 mgmt-id
→ 引擎节点预检
→ 上传并核对引擎包 MD5
→ 安装引擎节点
→ docker ps + minion engine health
→ 生成部署报告
```

分布式引擎节点依赖管理节点任务状态为 `completed`，并使用经过平台采集确认的 `mgmt-ip`、`mgmt-id`，不能由 AI 生成。

## 环境预检

硬阻断项：

- SSH、主机指纹、白名单和安装包完整性失败。
- 操作系统不在手册支持清单。
- 内核低于 3.10；缺少 `iptable_nat` 或 `iptable_filter`。
- 文件系统为 XFS 但 `ftype != 1`。
- 管理节点端口 TCP 443/12345/12346 或 UDP 1194 被占用。
- 管理节点 Docker 网段 `169.254.1.0/24` 或内部网段 `169.253.0.0/16` 冲突。
- 分布式引擎无法连接管理节点必要端口。
- 分布式引擎缺少 `mgmt-ip`、`mgmt-id` 或 `engine-ip`。

风险告警项（允许人工确认后继续）：

- 管理节点低于推荐 8 核、32 GiB、500 GB，但不得低于适配后的最低线。
- 引擎节点低于推荐 8 核、16 GiB、100 GB，但不得低于适配后的最低线。
- 内核低于推荐 4.15、umask 非 0022、系统资源参数未达到手册建议。

手册不同章节出现了管理节点最低磁盘 128 GB 与安装器检查 80 GiB 两个口径。Agent 默认采用更严格的 128 GB；变更必须经过产品评审。

## 固定步骤模板

管理节点：`mgmt.package_hash`、`mgmt.upload`、`mgmt.install`、`mgmt.docker_status`、`mgmt.health`、`mgmt.read_id`。

引擎节点：`engine.package_hash`、`engine.upload`、`engine.install_standalone`、`engine.install_distributed`、`engine.docker_status`、`engine.health`。

页面只能提交步骤所需的结构化参数，不能提交 Shell。安装包密码、SSH 密码、外部数据库密码不得进入任务 API、日志或持久化存储。

## 页面字段

通用字段：具体版本、模式、节点类型、目标节点、SSH 配置、安装包、安装包密码、安装目录（默认 `/data/x-ray`）。

管理节点可选字段：https 端口、管理监听 IP、Docker 子网、OpenVPN 子网/端口、是否外部 PostgreSQL。高级参数默认隐藏并受策略约束。

分布式引擎必填字段：`engine_ip`、`mgmt_ip`、`mgmt_id`、与管理节点一致的 HTTPS 端口。

## 验收条件

- 管理节点：容器全部启动，`/data/x-ray/minion mgmt health` 全部健康，Web 管理端口可连接。
- 引擎节点：容器全部启动，`/data/x-ray/minion engine health` 全部健康，管理节点可观察到引擎注册。
- “命令退出码为 0”不能单独作为部署成功依据。
