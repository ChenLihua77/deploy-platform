# 产品自动部署工作台（Deploy Center）

一个使用 Go 实现的多产品自动部署控制平台。工作台统一管理产品 Agent、目标节点、部署预检、正式安装、任务日志和审计记录，并通过固定步骤模板约束远程执行行为。

> 当前项目仍处于开发验证阶段。部署操作可能连接远程主机并执行安装步骤，只能对已授权的测试或交付节点使用。执行前请核对产品版本、安装介质、目标地址和变更授权。

## 功能概览

- 统一展示和管理多个产品部署 Agent
- 维护允许部署的目标节点白名单
- 在正式安装前执行环境和安装介质预检
- 对风险项进行显式提示，并要求填写继续执行原因
- 正式安装前进行二次确认，并校验预检任务与部署参数一致
- 异步执行任务并在页面实时展示状态和日志
- 记录节点新增、删除等管理操作的审计日志
- 产品 Agent 只接受结构化参数，不接受页面或 AI 提交任意 Shell 命令
- 节点和审计数据以权限为 `0600` 的本地 JSON 文件保存

## 产品支持状态

| 产品 | 标识 | 已注册能力 | 当前实现状态 |
| --- | --- | --- | --- |
| 洞鉴 X-Ray | `dongjian` | 单机/分布式，管理节点/引擎节点 | 已提供工作台、预检和部署 Runtime |
| 牧云 CloudWalker | `muyun` | 单机/K8s，管理节点/Linux/Windows Agent | 已提供单机管理端工作台、预检和部署 Runtime |
| 全悉 T-Answer | `quanxi` | 26.04.001 软件单机管理节点 | 已提供工作台、预检和部署 Runtime |
| 谛听 D-Sensor | `diting` | 软件管理节点及多类探针 | 已注册介质预检与任务 Runtime；正式安装保持安全阻断 |
| 雷池 SafeLine | `safeline` | 23.01.014 反向代理单机版 | 已提供工作台、预检和部署 Runtime |

各产品的设计依据、预检规则和能力边界见 [`docs/`](docs/) 目录。

## 技术栈

- Go 1.22+
- Go 标准库 `net/http`
- `golang.org/x/crypto`
- 原生 HTML、CSS 和 JavaScript（嵌入 Go 源码，无前端构建依赖）

## 项目结构

```text
.
├── cmd/controller/       # HTTP 控制器、路由和工作台页面
├── internal/
│   ├── agent/            # 产品 Agent 接口和能力模型
│   ├── core/             # 通用任务状态
│   ├── executor/         # 受控执行器接口
│   ├── nodes/            # 节点白名单和审计存储
│   ├── registry/         # 产品 Agent 注册中心
│   └── security/         # 目标节点授权策略
├── products/             # 各产品 Agent 与 Runtime
├── docs/                 # 产品部署 Agent 设计文档
├── data/                 # 节点和审计运行数据
└── go.mod
```

## 快速启动

### 从源码运行

```bash
cd /Users/chenlihua/Documents/Codex/2026-08-04/he/deploy-platform
go mod download
go run ./cmd/controller
```

也可以先构建再运行：

```bash
go build -o deploy-controller ./cmd/controller
./deploy-controller
```

启动后访问：

- 工作台：<http://127.0.0.1:18090/>
- 健康检查：<http://127.0.0.1:18090/health>
- 产品能力接口：<http://127.0.0.1:18090/api/v1/products>

服务目前固定监听 `127.0.0.1:18090`，仅允许本机访问。

## 构建

```bash
go build -o deploy-controller ./cmd/controller
```

构建产物与当前操作系统、CPU 架构相关。在其他平台部署时，应在目标平台构建或配置交叉编译。

## 目标节点管理

部署 Runtime 只允许操作已加入工作台白名单的目标节点。默认只接受私网 IP：

```bash
curl -X POST http://127.0.0.1:18090/api/v1/nodes \
  -H 'Content-Type: application/json' \
  -d '{
    "ip": "192.168.10.20",
    "name": "测试节点",
    "note": "部署验证"
  }'
```

查询节点：

```bash
curl http://127.0.0.1:18090/api/v1/nodes
```

删除节点：

```bash
curl -X DELETE http://127.0.0.1:18090/api/v1/nodes/192.168.10.20
```

节点和审计数据分别保存在：

- `data/nodes.json`
- `data/audit.json`

### 公网测试节点例外

默认禁止添加公网 IP。确有授权测试需求时，可以显式开启临时例外：

```bash
DEPLOY_ALLOW_PUBLIC_TEST_TARGET=true ./deploy-controller
```

该选项只放宽“添加公网节点”的限制，不代表目标主机已获得部署授权。生产环境不建议开启。

## 部署流程

已注册 Runtime 的产品遵循以下基本流程：

```text
添加授权节点
→ 填写结构化部署参数
→ 执行预检
→ 处理硬阻断项和风险告警
→ 使用相同参数发起正式安装
→ 二次确认
→ 执行固定步骤模板
→ 查看任务日志与验收结果
```

预检通过后修改任何关键参数，都应重新执行预检。存在风险告警时，必须由操作人员填写继续部署原因。

## 页面入口

| 页面 | 地址 |
| --- | --- |
| 控制台 | `/` |
| 雷池部署 | `/safeline/deploy` |
| 洞鉴部署 | `/dongjian/deploy` |
| 牧云部署 | `/muyun/deploy` |
| 全悉部署 | `/quanxi/deploy` |
| 谛听部署 | `/diting/deploy` |

## API 概览

### 平台接口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/health` | 健康状态和已注册 Agent 数量 |
| `GET` | `/api/v1/products` | 产品能力列表 |
| `GET` | `/api/v1/nodes` | 目标节点列表 |
| `POST` | `/api/v1/nodes` | 添加目标节点 |
| `DELETE` | `/api/v1/nodes/{ip}` | 删除目标节点 |
| `GET` | `/api/v1/audit` | 查询审计记录 |

### 产品任务接口

洞鉴、牧云和全悉目前分别提供以下形式的接口：

```text
POST /api/v1/{product}/precheck
POST /api/v1/{product}/deploy
GET  /api/v1/{product}/tasks/{id}
```

其中 `{product}` 可为 `safeline`、`dongjian`、`muyun` 或 `quanxi`。请求字段和产品约束以对应页面及 `products/<product>/runtime.go` 为准。

## 安全设计

- 服务只监听本机回环地址，不直接暴露到局域网或公网
- 目标 IP 必须在节点白名单中
- 默认拒绝公网目标节点
- 页面提交结构化参数，产品 Agent 不接受任意 Shell
- 执行步骤由代码中的固定模板定义
- 正式安装必须依赖已通过的预检任务
- 部署参数改变后，旧预检结果不可复用
- 风险继续执行需要人工确认和原因说明
- SSH 密码、安装包密码等敏感字段不应写入日志或持久化文件
- 不自动执行未经专项评审的格式化磁盘、修改网络、防火墙、批量重启等高风险操作

## 开发新产品 Agent

新产品需要实现 `internal/agent.ProductAgent`：

```go
type ProductAgent interface {
    Capabilities() Capability
    Validate(Request) error
    Precheck(context.Context, Request, Logger) (PrecheckResult, error)
    Deploy(context.Context, Request, Logger) error
    Verify(context.Context, Request, Logger) error
}
```

建议开发顺序：

1. 在 `docs/` 编写产品能力、安全边界和验收标准。
2. 在 `products/<product>/` 实现能力模型和参数校验。
3. 将远程动作拆分为固定、可审核的步骤模板。
4. 实现预检、部署、验证和任务查询 Runtime。
5. 在 `cmd/controller/main.go` 注册 Agent 和路由。
6. 使用已授权的隔离测试节点完成端到端验证。

## SSH 代理端口

每个产品部署页面都支持填写“SSH 代理端口”，默认值为 `22`。当堡垒机、端口映射或代理将目标 SSH 服务暴露在其他端口时，填写映射后的端口，例如 `2222`。平台会连接 `目标节点 IP:SSH 代理端口`；端口必须在 `1-65535` 范围内，并且预检和正式安装必须使用同一端口。

自定义端口的主机指纹需要以 OpenSSH 的 `[host]:port` 格式存在于 `known_hosts` 中，例如：

```text
[192.168.10.20]:2222 ssh-ed25519 AAAA...
```

### 临时跳过主机指纹校验（仅测试）

如目标是一次性测试主机且无法维护 `known_hosts`，可显式设置：

```bash
DEPLOY_INSECURE_SKIP_HOST_KEY_CHECK=true ./deploy-controller
```

该开关会让所有产品使用 `ssh.InsecureIgnoreHostKey()`，存在中间人攻击风险，禁止在生产环境或不可信网络中使用。默认未设置时仍执行严格指纹校验。

## SSH 密码加密持久化

设置 `DEPLOY_CREDENTIAL_KEY` 后，平台会使用 AES-256-GCM 将 SSH 密码加密保存到 `data/ssh-credentials.enc`：

```bash
export DEPLOY_CREDENTIAL_KEY='请使用足够长的随机密钥'
./deploy-controller
```

密码按“目标 IP、SSH 代理端口、SSH 用户”分别保存。首次部署需要填写密码；后续相同连接信息可以将密码留空。可通过 `DEPLOY_CREDENTIAL_FILE` 修改加密文件路径。

密钥不会写入项目文件。必须妥善备份并在每次启动时提供相同密钥；密钥变化后旧凭据无法解密。不要将密钥或 `data/ssh-credentials.enc` 提交到 Git。

## 当前限制

- 暂未提供登录认证、RBAC 或多人权限隔离
- 任务主要保存在进程内，服务重启后任务状态可能丢失
- 当前节点和审计数据使用本地 JSON，不适合多实例并发部署
- 谛听正式安装仍需完成 DS-S40-25.12.001 实际介质和验收标准验证
- 不同产品的实际安装介质和命令仍需按具体版本适配、审核和验证
- 项目尚未提供完整自动化测试与 CI 配置

## 停止服务

前台运行时按 `Ctrl+C`。如果需要按端口查找进程：

```bash
lsof -nP -iTCP:18090 -sTCP:LISTEN
```
